package com.mycompany.p1proyectosinmaleza_semanate;

import java.util.ArrayList;
import java.util.List;

/*public class Pregunta {
    private String texto;
    private ArrayList<String> opciones;
    private int[] conteoRespuestas;

    public Pregunta(String texto, ArrayList<String> opciones) {
        this.texto = texto;
        this.opciones = opciones;
        this.conteoRespuestas = new int[opciones.size()];
    }

    public String getTexto() {
        return texto;
    }

    public ArrayList<String> getOpciones() {
        return opciones;
    }

    public void registrarRespuesta(int indice) {
        if (indice >= 0 && indice < conteoRespuestas.length) {
            conteoRespuestas[indice]++;
        }
    }

    public void mostrarResultados() {
        System.out.println("Resultados de la pregunta: " + texto);
        for (int i = 0; i < opciones.size(); i++) {
            System.out.println(opciones.get(i) + ": " + conteoRespuestas[i] + " votos");
        }
    }
}*/
/*public class Pregunta {
    private String texto;

    public Pregunta(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}*/
public class Pregunta {
    private String texto;
    private boolean opcionMultiple;
    private List<String> opciones;

    public Pregunta(String texto, boolean opcionMultiple) {
        this.texto = texto;
        this.opcionMultiple = opcionMultiple;
        if (opcionMultiple) {
            this.opciones = new ArrayList<>();
        }
    }

    public String getTexto() {
        return texto;
    }

    public boolean isOpcionMultiple() {
        return opcionMultiple;
    }

    public void agregarOpcion(String opcion) {
        if (opcionMultiple) {
            opciones.add(opcion);
        }
    }

    public List<String> getOpciones() {
        return opciones;
    }
}
