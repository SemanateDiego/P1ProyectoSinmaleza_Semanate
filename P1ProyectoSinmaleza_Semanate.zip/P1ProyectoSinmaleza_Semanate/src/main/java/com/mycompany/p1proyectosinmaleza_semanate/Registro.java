package com.mycompany.p1proyectosinmaleza_semanate;

//Librerias
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Registro {
    Scanner scanner = new Scanner(System.in);

    ArrayList<Administrador> listaAdministradores = new ArrayList<>();
    ArrayList<Encuestado> listaEncuestados = new ArrayList<>();

    public void menuRegistro() {
        int opcion;

        do {
            System.out.println("\n=== MENU DE REGISTRO ===");
            System.out.println("1. Registro de Administrador");
            System.out.println("2. Registro de Encuestado");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = scanner.nextInt();
            scanner.nextLine();// Limpiar el buffer 

            switch (opcion) {
                case 1:
                    registrarAdministrador();
                    break;
                case 2:
                    registrarEncuestado();
                    break;
                case 3:
                    System.out.println("Saliendo del menu de registro...");
                    break;
                default:
                    System.out.println("Opcion incorrecta. Intente de nuevo.");
            }
        } while (opcion != 3);
    }

    private void registrarAdministrador() {
        System.out.println("\n--- REGISTRO DE ADMINISTRADOR ---");

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Cedula: ");
        String cedula = scanner.nextLine();

        System.out.print("Correo: ");
        String correo = scanner.nextLine();

        System.out.print("Telefono: ");
        String telefono = scanner.nextLine();

        System.out.print("Usuario: ");
        String usuario = scanner.nextLine();

        System.out.print("Contrasena: ");
        String contrasena = scanner.nextLine();

        System.out.print("Rol: ");
        String rol = scanner.nextLine();

        Administrador nuevoAdmin = new Administrador(rol, nombre, apellido, cedula, correo, telefono, usuario, contrasena);
        listaAdministradores.add(nuevoAdmin);

        guardarAdministradorEnCSV(nuevoAdmin);
    }

    private void registrarEncuestado() {
        System.out.println("\n--- REGISTRO DE ENCUESTADO ---");

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Cedula: ");
        String cedula = scanner.nextLine();

        System.out.print("Correo: ");
        String correo = scanner.nextLine();

        System.out.print("Telefono: ");
        String telefono = scanner.nextLine();

        System.out.print("Usuario: ");
        String usuario = scanner.nextLine();

        System.out.print("Contrasena: ");
        String contrasena = scanner.nextLine();

        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Genero: ");
        String genero = scanner.nextLine();

        boolean completado = false;

        Encuestado nuevoEncuestado = new Encuestado(edad, genero, completado, nombre, apellido, cedula, correo, telefono, usuario, contrasena);
        listaEncuestados.add(nuevoEncuestado);

        guardarEncuestadoEnCSV(nuevoEncuestado);
    }

    // === Metodos para guardar automaticamente en CSV ===

    public static void guardarAdministradorEnCSV(Administrador admin) {
        String fileName = "administradores.csv";
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.write(admin.getRol() + "," +
                         admin.getNombre() + "," +
                         admin.getApellido() + "," +
                         admin.getCedula() + "," +
                         admin.getCorreo() + "," +
                         admin.getTelefono() + "," +
                         admin.getUsuario() + "," +
                         admin.getConstrasenia() + "\n");
            System.out.println("Administrador guardado correctamente en '" + fileName + "'.");
        } catch (IOException e) {
            System.out.println("Error al guardar en el archivo CSV: " + e.getMessage());
        }
    }

    public static void guardarEncuestadoEnCSV(Encuestado enc) {
        String fileName = "encuestados.csv";
        try (FileWriter writer = new FileWriter(fileName, true)) {
            writer.write(enc.getEdad() + "," +
                         enc.getGenero() + "," +
                         enc.isEncuestaCompletada() + "," +
                         enc.getNombre() + "," +
                         enc.getApellido() + "," +
                         enc.getCedula() + "," +
                         enc.getCorreo() + "," +
                         enc.getTelefono() + "," +
                         enc.getUsuario() + "," +
                         enc.getConstrasenia() + "\n");
            System.out.println("Encuestado guardado correctamente en '" + fileName + "'.");
        } catch (IOException e) {
            System.out.println("Error al guardar en el archivo CSV: " + e.getMessage());
        }
    }
}


