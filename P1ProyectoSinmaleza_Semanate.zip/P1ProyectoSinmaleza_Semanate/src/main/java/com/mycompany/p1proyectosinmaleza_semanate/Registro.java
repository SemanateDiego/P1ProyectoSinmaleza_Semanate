package com.mycompany.p1proyectosinmaleza_semanate;

public class Registro {
    
}
