package com.mycompany.p1proyectosinmaleza_semanate;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*public class Login {
    private List<Administrador> admins = new ArrayList<>();
    private List<Encuestado> encuestados = new ArrayList<>();
    private List<Encuesta> encuestas = new ArrayList<>();
    
    public void login(Scanner scanner) {
        System.out.print("Correo: ");
        String correo = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        for (Administrador a : admins) {
            if (a.getCorreo().equals(correo) && a.getConstrasenia().equals(contrasena)) {
                System.out.println("Bienvenido admin " + a.getNombre());
                a.crearEncuesta(this, scanner);
                return;
            }
        }

        for (Encuestado e : encuestados) {
            if (e.getCorreo().equals(correo) && e.getConstrasenia().equals(contrasena)) {
                System.out.println("Bienvenido encuestado " + e.getNombre());
                e.responderEncuesta(encuestas, scanner);
                return;
            }
        }

        System.out.println("Usuario o contraseña incorrectos.");
    }

    public void agregarEncuesta(Encuesta encuesta) {
        encuestas.add(encuesta);
    }
}*/
