package com.mycompany.p1proyectosinmaleza_semanate;

public class Persona {
    //Atributos
    private String nombre,apellido,cedula,correo,telefono;
    private String usuario,constrasenia;
    //Constructor
    public Persona(String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String constrasenia) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.correo = correo;
        this.telefono = telefono;
        this.usuario = usuario;
        this.constrasenia = constrasenia;
    }
    //Getters y setters
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public String getCedula() {
        return cedula;
    }
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }
    public String getCorreo() {
        return correo;
    }
    public void setCorreo(String correo) {
        this.correo = correo;
    }
    public String getTelefono() {
        return telefono;
    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    public String getUsuario() {
        return usuario;
    }
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    public String getConstrasenia() {
        return constrasenia;
    }
    public void setConstrasenia(String constrasenia) {
        this.constrasenia = constrasenia;
    }
}
