package com.mycompany.p1proyectosinmaleza_semanate;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/*public class Sistema {
    private List<Administrador> admins = new ArrayList<>();
    private List<Encuestado> encuestados = new ArrayList<>();
    private List<Encuesta> encuestas = new ArrayList<>();

    public void registrarUsuario(Scanner scanner) {
        System.out.print("Ingrese su nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese su correo: ");
        String correo = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String contrasena = scanner.nextLine();

        System.out.print("¿Es administrador (s/n)?: ");
        String tipo = scanner.nextLine();

        if (tipo.equalsIgnoreCase("s")) {
            admins.add(new Administrador(tipo, nombre, tipo, correo, correo, tipo, correo, contrasena));
            System.out.println("Administrador registrado.");
        } else {
            encuestados.add(new Encuestado(0, tipo, true, nombre, tipo, correo, correo, tipo, correo, contrasena));
            System.out.println("Encuestado registrado.");
        }
    }

    public void login(Scanner scanner) {
        System.out.print("Correo: ");
        String correo = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        for (Administrador a : admins) {
            if (a.getCorreo().equals(correo) && a.getConstrasenia().equals(contrasena)) {
                System.out.println("Bienvenido administrador " + a.getNombre());
                a.crearEncuesta(this, scanner);
                return;
            }
        }

        for (Encuestado e : encuestados) {
            if (e.getCorreo().equals(correo) && e.getConstrasenia().equals(contrasena)) {
                System.out.println("Bienvenido encuestado " + e.getNombre());
                e.responderEncuesta(encuestas, scanner);
                return;
            }
        }

        System.out.println("Usuario o contrasenia incorrectos.");
    }

    public void agregarEncuesta(Encuesta encuesta) {
        encuestas.add(encuesta);
    }
}*/
public class Sistema {
    private List<Administrador> admins = new ArrayList<>();
    private List<Encuestado> encuestados = new ArrayList<>();
    private List<Encuesta> encuestas = new ArrayList<>();

    public void registrarUsuario(Scanner scanner) {
        System.out.print("Ingrese su nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese su correo: ");
        String correo = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String contrasena = scanner.nextLine();

        System.out.print("¿Es administrador (s/n)?: ");
        String tipo = scanner.nextLine();

        if (tipo.equalsIgnoreCase("s")) {
            admins.add(new Administrador(tipo, nombre, tipo, correo, correo, tipo, correo, contrasena));
            System.out.println("Administrador registrado.");
        } else {
            encuestados.add(new Encuestado(0, tipo, true, nombre, tipo, correo, correo, tipo, correo, contrasena));
            System.out.println("Encuestado registrado.");
        }
    }

    public void login(Scanner scanner) {
        System.out.print("Correo: ");
        String correo = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();

        for (Administrador a : admins) {
            if (a.getCorreo().equals(correo) && a.getConstrasenia().equals(contrasena)) {
                System.out.println("Bienvenido admin " + a.getNombre());
                a.crearEncuesta(this, scanner);
                return;
            }
        }

        for (Encuestado e : encuestados) {
            if (e.getCorreo().equals(correo) && e.getConstrasenia().equals(contrasena)) {
                System.out.println("Bienvenido encuestado " + e.getNombre());
                e.responderEncuesta(encuestas, scanner);
                return;
            }
        }

        System.out.println("Usuario o contraseña incorrectos.");
    }

    public void agregarEncuesta(Encuesta encuesta) {
        encuestas.add(encuesta);
    }
}
