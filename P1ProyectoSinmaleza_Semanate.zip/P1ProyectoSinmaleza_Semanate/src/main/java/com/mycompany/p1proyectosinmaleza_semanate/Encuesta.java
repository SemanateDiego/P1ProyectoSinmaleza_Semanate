/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.p1proyectosinmaleza_semanate;
import java.util.*;

public class Encuesta {
    private String titulo;
    private List<Pregunta> preguntas;

    public Encuesta(String titulo) {
        this.titulo = titulo;
        this.preguntas = new ArrayList<>();
    }

    public String getTitulo() {
        return titulo;
    }

    public void agregarPregunta(Pregunta pregunta) {
        preguntas.add(pregunta);
    }

    public List<Pregunta> getPreguntas() {
        return preguntas;
    }
}

