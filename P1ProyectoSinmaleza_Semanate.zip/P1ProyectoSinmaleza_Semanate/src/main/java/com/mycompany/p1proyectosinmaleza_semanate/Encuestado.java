package com.mycompany.p1proyectosinmaleza_semanate;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Encuestado extends Persona{
    //Atributos
    private int edad;
    private String genero;
    private boolean encuestaCompletada;
    //Constructor
    public Encuestado(int edad, String genero,boolean encuestaCompletada, String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String constraseña) {
        super(nombre, apellido, cedula, correo, telefono, usuario, constraseña);
        this.edad = edad;
        this.genero = genero; 
        this.encuestaCompletada = encuestaCompletada;
    }
    //Getters y setters
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public boolean isEncuestaCompletada() {
        return encuestaCompletada;
    }
    public void setEncuestaCompletada(boolean encuestaCompletada) {
        this.encuestaCompletada = encuestaCompletada;
    }
    //Metodos Propios
    /*public void responderEncuesta(ArrayList<Pregunta> bancoPreguntas, Scanner sc) {
    if (bancoPreguntas.isEmpty()) {
        System.out.println("No hay preguntas disponibles.");
        return;
    }

    for (Pregunta p : bancoPreguntas) {
        System.out.println("\n" + p.getTexto());
        ArrayList<String> opciones = p.getOpciones();
        for (int i = 0; i < opciones.size(); i++) {
            System.out.println((i + 1) + ". " + opciones.get(i));
        }
        System.out.print("Selecciona una opción (1-" + opciones.size() + "): ");
        int seleccion = sc.nextInt() - 1;
        sc.nextLine(); // limpiar buffer
        p.registrarRespuesta(seleccion);
    }
    System.out.println("Gracias por responder la encuesta.");
}*/
/*public void responderEncuesta(List<Encuesta> encuestas, Scanner scanner) {
        if (encuestas.isEmpty()) {
            System.out.println("No hay encuestas disponibles.");
            return;
        }

        System.out.println("Encuestas disponibles:");
        for (int i = 0; i < encuestas.size(); i++) {
            System.out.println((i + 1) + ". " + encuestas.get(i).getTitulo());
        }

        System.out.print("Seleccione el número de la encuesta que desea responder: ");
        int seleccion = scanner.nextInt();
        scanner.nextLine();

        if (seleccion < 1 || seleccion > encuestas.size()) {
            System.out.println("Selección inválida.");
            return;
        }

        Encuesta encuestaSeleccionada = encuestas.get(seleccion - 1);
        List<Respuesta> respuestas = new ArrayList<>();

        System.out.println("Respondiendo: " + encuestaSeleccionada.getTitulo());
        for (Pregunta p : encuestaSeleccionada.getPreguntas()) {
            System.out.println(p.getTexto());
            System.out.print("Tu respuesta: ");
            String resp = scanner.nextLine();
            respuestas.add(new Respuesta(resp));
        }

        System.out.println("Gracias por completar la encuesta.");
    }*/
    public void responderEncuesta(List<Encuesta> encuestas, Scanner scanner) {
        if (encuestas.isEmpty()) {
            System.out.println("No hay encuestas disponibles.");
            return;
        }

        System.out.println("Encuestas disponibles:");
        for (int i = 0; i < encuestas.size(); i++) {
            System.out.println((i + 1) + ". " + encuestas.get(i).getTitulo());
        }

        System.out.print("Seleccione el número de la encuesta que desea responder: ");
        int seleccion = scanner.nextInt();
        scanner.nextLine();

        if (seleccion < 1 || seleccion > encuestas.size()) {
            System.out.println("Selección inválida.");
            return;
        }

        Encuesta encuestaSeleccionada = encuestas.get(seleccion - 1);
        List<Respuesta> respuestas = new ArrayList<>();

        System.out.println("Respondiendo: " + encuestaSeleccionada.getTitulo());
        for (Pregunta p : encuestaSeleccionada.getPreguntas()) {
            System.out.println(p.getTexto());
            if (p.isOpcionMultiple()) {
                List<String> opciones = p.getOpciones();
                for (int i = 0; i < opciones.size(); i++) {
                    System.out.println((i + 1) + ". " + opciones.get(i));
                }
                System.out.print("Seleccione una opción: ");
                int opcion = scanner.nextInt();
                scanner.nextLine();
                if (opcion >= 1 && opcion <= opciones.size()) {
                    respuestas.add(new Respuesta(opciones.get(opcion - 1)));
                } else {
                    System.out.println("Opción inválida.");
                    respuestas.add(new Respuesta("Sin respuesta válida"));
                }
            } else {
                System.out.print("Tu respuesta: ");
                String resp = scanner.nextLine();
                respuestas.add(new Respuesta(resp));
            }
        }

        System.out.println("Gracias por completar la encuesta.");
    }
    
}
