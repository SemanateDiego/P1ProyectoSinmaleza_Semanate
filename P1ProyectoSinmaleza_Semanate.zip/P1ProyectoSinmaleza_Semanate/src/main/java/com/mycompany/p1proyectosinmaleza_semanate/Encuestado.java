package com.mycompany.p1proyectosinmaleza_semanate;

public class Encuestado extends Persona{
    //Atributos
    private int edad;
    private String genero;
    private boolean encuestaCompletada;
    //Constructor
    public Encuestado(int edad, String genero, boolean encuestaCompletada, String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String constrasenia) {
        super(nombre, apellido, cedula, correo, telefono, usuario, constrasenia);
        this.edad = edad;
        this.genero = genero;
        this.encuestaCompletada = encuestaCompletada;
    }
    //Getters y setters
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public boolean isEncuestaCompletada() {
        return encuestaCompletada;
    }
    public void setEncuestaCompletada(boolean encuestaCompletada) {
        this.encuestaCompletada = encuestaCompletada;
    }
    //Metodos Propios
    public void responderEncuesta(){
        
    }
    
}
