package com.mycompany.p1proyectosinmaleza_semanate;

public class Administrador extends Persona{
    //Atributos
    private String rol; // por ejemplo: "Administrador General", "Supervisor"
    //Constructor
    public Administrador(String rol, String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String constrasenia) {    
        super(nombre, apellido, cedula, correo, telefono, usuario, constrasenia);
        this.rol = rol;
    }
    //Getters y setters
    public String getRol() {
        return rol;
    }
    public void setRol(String rol) {
        this.rol = rol;
    }
    //Metodos Propios
    public void generarEncuesta(){
        
    }
    public void eliminarEncuesta(){
        
    }
    public void generarReporte(){
        
    }
    
}
