package com.mycompany.p1proyectosinmaleza_semanate;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Administrador extends Persona{
    //Atributos
    private String rol; // por ejemplo: "Administrador General", "Supervisor"
    //Constructor
    public Administrador(String rol, String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String constraseña) {    
        super(nombre, apellido, cedula, correo, telefono, usuario, constraseña);
        this.rol = rol;
    }
    //Getters y setters
    public String getRol() {
        return rol;
    }
    public void setRol(String rol) {
        this.rol = rol;
    }
    //Metodos Propios
    /*public void crearPregunta(ArrayList<Pregunta> bancoPreguntas, Scanner sc) {
    System.out.print("Escribe la pregunta: ");
    String texto = sc.nextLine();

    ArrayList<String> opciones = new ArrayList<>();
    System.out.println("Ingresa opciones (mínimo 2, escribe 'fin' para terminar):");
    while (true) {
        String opcion = sc.nextLine();
        if (opcion.equalsIgnoreCase("fin") && opciones.size() >= 2) break;
        if (!opcion.isEmpty()) opciones.add(opcion);
        else System.out.println("Opción no válida.");
    }

    bancoPreguntas.add(new Pregunta(texto, opciones));
    System.out.println("Pregunta agregada con éxito.");
}*/
    /*public void crearEncuesta(Sistema sistema, Scanner scanner) {
        System.out.print("Ingrese el título de la encuesta: ");
        String titulo = scanner.nextLine();
        Encuesta nueva = new Encuesta(titulo);

        String respuesta;
        do {
            System.out.print("Ingrese una pregunta: ");
            String texto = scanner.nextLine();
            nueva.agregarPregunta(new Pregunta(texto));
            System.out.print("¿Desea agregar otra pregunta? (s/n): ");
            respuesta = scanner.nextLine();
        } while (respuesta.equalsIgnoreCase("s"));

        sistema.agregarEncuesta(nueva);
        System.out.println("Encuesta guardada con éxito.");
    }*/
    public void crearEncuesta(Sistema sistema, Scanner scanner) {
        System.out.print("Ingrese el título de la encuesta: ");
        String titulo = scanner.nextLine();
        Encuesta nueva = new Encuesta(titulo);

        String respuesta;
        do {
            System.out.print("Ingrese una pregunta: ");
            String texto = scanner.nextLine();

            System.out.print("¿Es de opción múltiple? (s/n): ");
            String tipo = scanner.nextLine();

            Pregunta pregunta;
            if (tipo.equalsIgnoreCase("s")) {
                pregunta = new Pregunta(texto, true);
                System.out.println("Ingrese las opciones (escriba 'fin' para terminar):");
                while (true) {
                    String opcion = scanner.nextLine();
                    if (opcion.equalsIgnoreCase("fin")) break;
                    pregunta.agregarOpcion(opcion);
                }
            } else {
                pregunta = new Pregunta(texto, false);
            }

            nueva.agregarPregunta(pregunta);
            System.out.print("¿Desea agregar otra pregunta? (s/n): ");
            respuesta = scanner.nextLine();
        } while (respuesta.equalsIgnoreCase("s"));

        sistema.agregarEncuesta(nueva);
        System.out.println("Encuesta guardada con éxito.");
    }
    public void generarEncuesta(){
        
    }
    public void eliminarEncuesta(){
        
    }
    public void generarReporte(){
        
    }
    
}
