package com.mycompany.p1proyectosinmaleza_semanate;
//Sistemas de encuestas
import java.util.*;
public class P1ProyectoSinmaleza_Semanate {

    //static ArrayList<Persona> usuarios = new ArrayList<>();
    //static ArrayList<Pregunta> bancoPreguntas = new ArrayList<>();

    /*public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Registrarse");
            System.out.println("2. Iniciar sesión");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    registrarUsuario(sc);
                    break;
                case 2:
                    loginUsuario(sc);
                    break;
                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 3);

        sc.close();
    }

    public static void registrarUsuario(Scanner sc) {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = sc.nextLine();
        System.out.print("Tipo (admin/encuestado): ");
        String tipo = sc.nextLine();

        if (tipo.equalsIgnoreCase("admin")) {
            usuarios.add(new Administrador(tipo, nombre, tipo, correo, correo, tipo, correo, contrasena));
        } else {
            usuarios.add(new Encuestado(0, tipo, true, nombre, tipo, correo, correo, tipo, correo, contrasena));
        }
        System.out.println("Usuario registrado con éxito.");
    }

    public static void loginUsuario(Scanner sc) {
        System.out.print("Correo: ");
        String correo = sc.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = sc.nextLine();

        for (Persona p : usuarios) {
            if (p.getCorreo().equals(correo) && p.getConstrasenia().equals(contrasena)) {
                System.out.println("\nBienvenido " + p.getNombre());

                if (p instanceof Administrador admin) {
                    int op;
                    do {
                        System.out.println("\n--- ADMIN ---");
                        System.out.println("1. Crear pregunta");
                        System.out.println("2. Ver resultados");
                        System.out.println("3. Cerrar sesión");
                        System.out.print("Seleccione: ");
                        op = sc.nextInt();
                        sc.nextLine();
                        if (op == 1) {
                            admin.crearPregunta(bancoPreguntas, sc);
                        } else if (op == 2) {
                            for (Pregunta preg : bancoPreguntas) {
                                preg.mostrarResultados();
                            }
                        }
                    } while (op != 3);
                } else if (p instanceof Encuestado encuestado) {
                    encuestado.responderEncuesta(bancoPreguntas, sc);
                }
                return;
            }
        }

        System.out.println("Credenciales incorrectas.");
    }*/
    /*public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Sistema sistema = new Sistema();

        int opcion;
        do {
            System.out.println("\n--- SISTEMA DE ENCUESTAS ---");
            System.out.println("1. Registrarse");
            System.out.println("2. Iniciar sesión");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    sistema.registrarUsuario(scanner);
                    break;
                case 2:
                    sistema.login(scanner);
                    break;
                case 3:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 3);

        scanner.close();
    }*/
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Sistema sistema = new Sistema();

        int opcion;
        do {
            System.out.println("\n--- SISTEMA DE ENCUESTAS ---");
            System.out.println("1. Registrarse");
            System.out.println("2. Iniciar sesión");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    sistema.registrarUsuario(scanner);
                    break;
                case 2:
                    sistema.login(scanner);
                    break;
                case 3:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 3);

        scanner.close();
    }
}
