package com.mycompany.p1proyectosinmaleza_semanate;
//Sistemas de encuestas

public class P1ProyectoSinmaleza_Semanate {

    public static void main(String[] args) {
        Registro  registro = new Registro ();
        registro.menuRegistro();
                 
    }
}
