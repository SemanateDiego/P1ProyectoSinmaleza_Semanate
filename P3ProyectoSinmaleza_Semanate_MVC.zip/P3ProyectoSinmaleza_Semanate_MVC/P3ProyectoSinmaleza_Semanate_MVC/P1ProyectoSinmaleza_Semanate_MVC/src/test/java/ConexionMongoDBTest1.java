import Modelo.DAO.ConexionMongoDB;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ConexionMongoDBTest1 {

    @Test
    void testObtenerColeccionNoNula() {
        ConexionMongoDB conexionMock = mock(ConexionMongoDB.class);
        MongoCollection<Document> collectionMock = mock(MongoCollection.class);

        when(conexionMock.getCollection("Administradores")).thenReturn(collectionMock);

        assertNotNull(conexionMock.getCollection("Administradores"), "La colección no debería ser nula");
    }

    @Test
    void testColeccionNombreCorrecto() {
        ConexionMongoDB conexionMock = mock(ConexionMongoDB.class);

        // Llamada simulada
        conexionMock.getCollection("Administradores");

        // Verifica que se haya llamado con el nombre correcto
        verify(conexionMock).getCollection("Administradores");
    }

    @Test
    void testColeccionConNombreVacio() {
        ConexionMongoDB conexionMock = mock(ConexionMongoDB.class);

        conexionMock.getCollection("");

        // Verifica que se haya llamado con una cadena vacía
        verify(conexionMock).getCollection("");
    }
}
