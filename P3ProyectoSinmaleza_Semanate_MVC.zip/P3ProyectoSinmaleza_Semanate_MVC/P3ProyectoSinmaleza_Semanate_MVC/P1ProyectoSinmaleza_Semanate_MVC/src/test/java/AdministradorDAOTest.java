import Modelo.Administrador;
import Modelo.DAO.AdministradorDAO;
import Modelo.DAO.ConexionMongoDB;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.FindIterable;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

public class AdministradorDAOTest {

    @Mock
    private ConexionMongoDB mockConexion;

    @Mock
    private MongoCollection<Document> mockCollection;

    @Mock
    private FindIterable<Document> mockFindIterable;

    private AdministradorDAO administradorDAO;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        //Cuando conexion.getCollection("Administradores") sea llamado, devolvemos mockCollection
        when(mockConexion.getCollection("Administradores")).thenReturn(mockCollection);

        administradorDAO = new AdministradorDAO(mockConexion);
    }

    @Test
    public void testGuardar_insertaDocumentoEnCollection() {
        Administrador admin = new Administrador("", "", "", "", "", "", "", "");
        admin.setRol("Admin");
        admin.setNombre("Juan");
        admin.setApellido("Perez");
        admin.setCedula("1234567890");
        admin.setCorreo("juan@mail.com");
        admin.setTelefono("0999999999");
        admin.setUsuario("juanp");
        admin.setContrasenia("1234");

        // Llamamos al método guardar
        administradorDAO.guardar(admin);

        // Verificamos que insertOne fue llamado con un Document que contiene los datos del admin
        ArgumentCaptor<Document> docCaptor = ArgumentCaptor.forClass(Document.class);
        verify(mockCollection).insertOne(docCaptor.capture());

        Document docInsertado = docCaptor.getValue();

        assertEquals("Admin", docInsertado.getString("rol"));
        assertEquals("Juan", docInsertado.getString("nombre"));
        assertEquals("Perez", docInsertado.getString("apellido"));
        assertEquals("1234567890", docInsertado.getString("cedula"));
        assertEquals("juan@mail.com", docInsertado.getString("correo"));
        assertEquals("0999999999", docInsertado.getString("telefono"));
        assertEquals("juanp", docInsertado.getString("usuario"));
        assertEquals("1234", docInsertado.getString("contrasenia"));
    }

    @Test
    public void testExistePorCedula_retornaTrueCuandoExiste() {
        String cedula = "1234567890";

        // Configuramos mockCollection.find(...) para que retorne un documento no nulo
        when(mockCollection.find(new Document("cedula", cedula))).thenReturn(mockFindIterable);
        when(mockFindIterable.first()).thenReturn(new Document("cedula", cedula));

        boolean resultado = administradorDAO.existePorCedula(cedula);

        assertTrue(resultado);
    }

    @Test
    public void testExistePorCedula_retornaFalseCuandoNoExiste() {
        String cedula = "0000000000";

        // Configuramos mockCollection.find(...) para que retorne null en first()
        when(mockCollection.find(new Document("cedula", cedula))).thenReturn(mockFindIterable);
        when(mockFindIterable.first()).thenReturn(null);

        boolean resultado = administradorDAO.existePorCedula(cedula);

        assertFalse(resultado);
    }
}
