
import Modelo.Validaciones.ValidadorCedula;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ValidarCedulaTest1 {

    private ValidadorCedula validador;

    @BeforeEach
    void setUp() {
        validador = new ValidadorCedula();
    }

    @Test
    void testCedulaValida() {
        assertTrue(validador.validar("0912312315"), "Debe validar correctamente una cédula válida");
    }

    @Test
    void testCedulaInvalidaDigitoVerificador() {
        assertFalse(validador.validar("0912312314"), "Debe rechazar cédula con dígito verificador incorrecto");
    }

    @Test
    void testCedulaConLetras() {
        assertFalse(validador.validar("09a2312315"), "Debe rechazar cédula con caracteres no numéricos");
    }

    @Test
    void testCedulaNula() {
        assertFalse(validador.validar(null), "Debe rechazar cédula nula");
    }

    @Test
    void testCedulaMuyCorta() {
        assertFalse(validador.validar("09123"), "Debe rechazar cédula con menos de 10 dígitos");
    }

    @Test
    void testCedulaMuyLarga() {
        assertFalse(validador.validar("09123123151"), "Debe rechazar cédula con más de 10 dígitos");
    }

    @Test
    void testMensajeError() {
        assertEquals("La cédula ingresada no es válida.", validador.mensajeError());
    }
}

