package Modelo.DAO;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class ConexionMongoDBTest2 {

    private ConexionMongoDB conexion;

    @BeforeEach
    void setUp() {
        conexion = new ConexionMongoDB();
    }

    @AfterEach
    void tearDown() {
        conexion.cerrarConexion();
    }

    @Test
    void ConexionMongoDBTest2_CrearConexion_NoDebeSerNulo() {
        assertNotNull(conexion, "La conexión no debe ser nula");
    }

    @Test
    void ConexionMongoDBTest2_GetDatabase_NoDebeSerNulo() {
        MongoDatabase db = conexion.getDatabase();
        assertNotNull(db, "La base de datos no debe ser nula");
        assertEquals("P2ProyectoGrupal", db.getName(), "El nombre de la base de datos debe ser P2ProyectoGrupal");
    }

    @Test
    void ConexionMongoDBTest2_GetCollection_DevuelveColeccionValida() {
        MongoCollection<Document> coleccion = conexion.getCollection("testCollection");
        assertNotNull(coleccion, "La colección no debe ser nula");
        assertEquals("testCollection", coleccion.getNamespace().getCollectionName(), "El nombre de la colección debe coincidir");
    }

    @Test
    void ConexionMongoDBTest2_CerrarConexion_NoLanzaExcepcion() {
        assertDoesNotThrow(() -> conexion.cerrarConexion(), "Cerrar conexión no debe lanzar excepción");
    }

    @Test
    void ConexionMongoDBTest2_ObtenerColeccionDiferente_DiferentesObjetos() {
        MongoCollection<Document> coleccion1 = conexion.getCollection("coleccion1");
        MongoCollection<Document> coleccion2 = conexion.getCollection("coleccion2");
        assertNotEquals(coleccion1.getNamespace().getCollectionName(), coleccion2.getNamespace().getCollectionName(),
                "Las colecciones deben ser distintas");
    }
}
