import PatronesDiseño.Memento;
import org.bson.Document;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class MementoTest {

    @Test
    public void testGetEstadoDevuelveCopiaSegura() {
        List<Document> estadoOriginal = new ArrayList<>();
        estadoOriginal.add(new Document("pregunta", "¿Cuál es tu color favorito?"));
        estadoOriginal.add(new Document("pregunta", "¿Te gusta el café?"));

        Memento memento = new Memento(estadoOriginal);

        // Recuperamos el estado desde el memento
        List<Document> copiaEstado = memento.getEstado();

        // Comprobamos que contiene los mismos elementos
        assertEquals(estadoOriginal.size(), copiaEstado.size());
        assertEquals(estadoOriginal.get(0), copiaEstado.get(0));
        assertEquals(estadoOriginal.get(1), copiaEstado.get(1));

        // Verificamos que es una copia (no la misma instancia)
        assertNotSame(estadoOriginal, copiaEstado);

        // Modificar la copia no debe afectar al memento
        copiaEstado.clear();
        assertEquals(2, memento.getEstado().size()); // El estado original del memento sigue intacto
    }
}
