import Modelo.Administrador;
import Modelo.DAO.AdministradorDAO;
import Modelo.DAO.ConexionMongoDB;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Iterator;

public class AdministradorDAOTest1 {

    private ConexionMongoDB conexionMock;
    private MongoCollection<Document> collectionMock;
    private AdministradorDAO dao;

    @BeforeEach
    void setUp() {
        conexionMock = mock(ConexionMongoDB.class);
        collectionMock = mock(MongoCollection.class);
        when(conexionMock.getCollection("Administradores")).thenReturn(collectionMock);
        dao = new AdministradorDAO(conexionMock);
    }

    @Test
    void testGuardarExitosamente() {
        Administrador admin = new Administrador(
                "Administrador",
                "Diego",
                "Semanate",
                "1234567890",
                "correo@ejemplo.com",
                "0987654321",
                "diego_user",
                "123456");

        dao.guardar(admin);

        verify(collectionMock, times(1)).insertOne(any(Document.class));
    }

    @Test
    void testExistePorCedula_True() {
        // Simula una colección que devuelve un documento
        Iterable<Document> iterable = () -> new Iterator<>() {
            private boolean hasReturned = false;

            public boolean hasNext() {
                return !hasReturned;
            }

            public Document next() {
                hasReturned = true;
                return new Document("cedula", "1234567890");
            }
        };

        when(collectionMock.find(any(Document.class))).thenReturn((FindIterable<Document>) iterable);

        boolean existe = dao.existePorCedula("1234567890");

        assertTrue(existe);
    }

    @Test
    void testExistePorCedula_False() {
        Iterable<Document> iterable = () -> new Iterator<>() {
            public boolean hasNext() { return false; }
            public Document next() { return null; }
        };

        when(collectionMock.find(any(Document.class))).thenReturn((FindIterable<Document>) iterable);

        boolean existe = dao.existePorCedula("0000000000");

        assertFalse(existe);
    }
}

