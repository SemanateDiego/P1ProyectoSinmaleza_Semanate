import main.P1ProyectoSinmaleza_Semanate;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

public class P1ProyectoSinmaleza_SemanateTest {

    @Test
    public void testMainEjecutaSinErrores() {
        assertDoesNotThrow(() -> P1ProyectoSinmaleza_Semanate.main(new String[]{}));
    }
}

