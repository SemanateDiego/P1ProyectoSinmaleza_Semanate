import PatronesDiseño.AgregarPreguntaCommand;
import Controlador.ControladorVistaEncuesta;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class AgregarPreguntaCommandTest {

    private ControladorVistaEncuesta mockControlador;
    private Document pregunta;
    private AgregarPreguntaCommand command;

    @BeforeEach
    public void setUp() {
        mockControlador = mock(ControladorVistaEncuesta.class);
        pregunta = new Document("texto", "¿Cuál es tu color favorito?");
        command = new AgregarPreguntaCommand(mockControlador, pregunta);
    }

    @Test
    public void testEjecutar_llamaAgregarPreguntaDesdeCommand() {
        command.ejecutar();
        verify(mockControlador, times(1)).agregarPreguntaDesdeCommand(pregunta);
    }

    @Test
    public void testDeshacer_llamaEliminarUltimaPreguntaDesdeCommand() {
        command.deshacer();
        verify(mockControlador, times(1)).eliminarUltimaPreguntaDesdeCommand();
    }
}
