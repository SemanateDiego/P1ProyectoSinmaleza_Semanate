import Modelo.Validaciones.ValidadorNoVacio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ValidadorNoVacioTest {

    private ValidadorNoVacio validador;

    @BeforeEach
    void setUp() {
        validador = new ValidadorNoVacio();
    }

    @Test
    void testValorValido() {
        assertTrue(validador.validar("Texto válido"), "Debe aceptar texto no vacío");
        assertEquals("", validador.getMensajeError(), "No debe mostrar mensaje de error cuando el valor es válido");
    }

    @Test
    void testValorVacio() {
        assertFalse(validador.validar(""), "Debe rechazar texto vacío");
        assertEquals("El campo no puede estar vacío", validador.getMensajeError(), "Debe mostrar mensaje de error");
    }

    @Test
    void testValorConEspacios() {
        assertFalse(validador.validar("   "), "Debe rechazar texto con solo espacios");
        assertEquals("El campo no puede estar vacío", validador.getMensajeError(), "Debe mostrar mensaje de error");
    }

    @Test
    void testValorNulo() {
        assertFalse(validador.validar(null), "Debe rechazar valor nulo");
        assertEquals("El campo no puede estar vacío", validador.getMensajeError(), "Debe mostrar mensaje de error");
    }
}

