
import Modelo.Validaciones.ValidadorCorreo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ValidadorCorreoTest1 {

    private ValidadorCorreo validador;

    @BeforeEach
    void setUp() {
        validador = new ValidadorCorreo();
    }

    @Test
    void testCorreoValido() {
        assertTrue(validador.validar("usuario@dominio.com"), "Debe aceptar un correo válido");
    }

    @Test
    void testCorreoSinArroba() {
        assertFalse(validador.validar("usuariodominio.com"), "Debe rechazar correo sin '@'");
    }

    @Test
    void testCorreoSinPunto() {
        assertFalse(validador.validar("usuario@dominio"), "Debe rechazar correo sin '.'");
    }

    @Test
    void testCorreoNulo() {
        assertFalse(validador.validar(null), "Debe rechazar correo nulo");
    }

    @Test
    void testCorreoVacio() {
        assertFalse(validador.validar(""), "Debe rechazar correo vacío");
    }

    @Test
    void testMensajeError() {
        assertEquals("El correo electrónico es inválido.", validador.mensajeError());
    }
}

