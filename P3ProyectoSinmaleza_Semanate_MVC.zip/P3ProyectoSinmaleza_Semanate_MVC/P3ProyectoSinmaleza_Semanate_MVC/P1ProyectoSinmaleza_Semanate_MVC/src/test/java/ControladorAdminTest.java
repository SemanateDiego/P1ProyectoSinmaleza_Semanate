import Controlador.ControladorAdmin;
import Modelo.Administrador;
import Modelo.Encuestado;
import Servicio.AdminService;
import Vista.Admin;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ControladorAdminTest {

    Admin mockVista;
    AdminService mockService;
    ControladorAdmin controlador;
    Administrador adminAutenticado;

    @BeforeEach
    public void setup() {
        // Creamos una instancia real con campos inicializados
        mockVista = new Admin() {
            {
                txtNombre = new JTextField();
                txtApellido = new JTextField();
                txtCedula = new JTextField();
                txtCorreo = new JTextField();
                txtTelefono = new JTextField();
                txtUsuario = new JTextField();
                txtContrasenia = new JTextField();
                tableDatos = new JTable();
                rbtnDescargarUsuarios = new JRadioButton();
                btnBuscar = new JButton();
                btnActualizar = new JButton();
                btnEliminar = new JButton();
                btnDescargar = new JButton();
            }
        };

        mockService = mock(AdminService.class);
        adminAutenticado = new Administrador("", "", "", "", "", "", "", "");

        List<Administrador> admins = new ArrayList<>();
        admins.add(adminAutenticado);
        when(mockService.cargarAdministradores(adminAutenticado)).thenReturn(admins);

        List<Encuestado> encuestados = new ArrayList<>();
        Encuestado e = new Encuestado(0, "", true, "", "", "", "", "", "", "");
        e.setCedula("123456");
        e.setNombre("Juan");
        e.setApellido("Perez");
        e.setCorreo("juan@mail.com");
        e.setTelefono("1234567890");
        e.setUsuario("juanp");
        e.setContrasenia("pass");
        encuestados.add(e);
        when(mockService.cargarEncuestados()).thenReturn(encuestados);

        controlador = new ControladorAdmin(mockVista, adminAutenticado, mockService);
    }

    @Test
    public void testBuscarEncuestadoEncontrado() {
        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            mocked.when(() -> JOptionPane.showInputDialog(any(), anyString())).thenReturn("123456");

            controlador.buscar();

            assertEquals("Juan", mockVista.txtNombre.getText());
            assertEquals("Perez", mockVista.txtApellido.getText());
            assertEquals("123456", mockVista.txtCedula.getText());

            assertFalse(mockVista.txtCedula.isEditable());

            mocked.verify(() -> JOptionPane.showMessageDialog(any(), anyString()), times(0));
        }
    }

    @Test
    public void testBuscarEncuestadoNoEncontrado() {
        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            mocked.when(() -> JOptionPane.showInputDialog(any(), anyString())).thenReturn("999999");

            controlador.buscar();

            mocked.verify(() -> JOptionPane.showMessageDialog(mockVista, "Encuestado no encontrado."), times(1));

            assertTrue(mockVista.txtNombre.getText().isEmpty());
            assertTrue(mockVista.txtApellido.getText().isEmpty());
        }
    }

    @Test
    public void testActualizarSinBuscar() {
        mockVista.txtCedula.setText("");

        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            controlador.actualizar();

            mocked.verify(() -> JOptionPane.showMessageDialog(mockVista, "Debe buscar un encuestado primero."), times(1));
        }
    }

    @Test
    public void testEliminarEncuestadoNoEncontrado() {
        mockVista.txtCedula.setText("999999");
        when(mockService.eliminarEncuestadoPorCedula("999999")).thenReturn(false);

        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            controlador.eliminar();

            mocked.verify(() -> JOptionPane.showMessageDialog(mockVista, "No se encontró el encuestado para eliminar."), times(1));
        }
    }

    @Test
    public void testDescargarSeleccionUsuariosSeleccionadoOK() {
        mockVista.rbtnDescargarUsuarios.setSelected(true);
        when(mockService.exportarUsuariosCSV(anyList(), anyList())).thenReturn(true);

        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            controlador.descargarSeleccion();

            mocked.verify(() -> JOptionPane.showMessageDialog(mockVista, "Usuarios exportados."), times(1));
        }
    }

    @Test
    public void testDescargarSeleccionUsuariosSeleccionadoError() {
        mockVista.rbtnDescargarUsuarios.setSelected(true);
        when(mockService.exportarUsuariosCSV(anyList(), anyList())).thenReturn(false);

        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            controlador.descargarSeleccion();

            mocked.verify(() -> JOptionPane.showMessageDialog(mockVista, "Error al exportar usuarios."), times(1));
        }
    }

    @Test
    public void testDescargarSeleccionNoSeleccionado() {
        mockVista.rbtnDescargarUsuarios.setSelected(false);

        try (MockedStatic<JOptionPane> mocked = mockStatic(JOptionPane.class)) {
            controlador.descargarSeleccion();

            mocked.verify(() -> JOptionPane.showMessageDialog(mockVista, "Seleccione una opción para descargar."), times(1));
        }
    }
}



