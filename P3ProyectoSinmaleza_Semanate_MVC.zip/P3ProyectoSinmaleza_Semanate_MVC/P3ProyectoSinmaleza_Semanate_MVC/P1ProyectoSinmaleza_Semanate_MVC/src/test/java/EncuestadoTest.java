

import Modelo.Encuestado;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EncuestadoTest {

    private Encuestado encuestado;

    @BeforeEach
    void setUp() {
        encuestado = new Encuestado(
                25, "M", false,
                "Carlos", "López", "1234567890", "carlos@email.com",
                "0999999999", "carlosUser", "secreta123"
        );
    }

    @Test
    void testConstructorYGetters() {
        assertEquals(25, encuestado.getEdad());
        assertEquals("M", encuestado.getGenero());
        assertFalse(encuestado.isEncuestaCompletada());

        assertEquals("Carlos", encuestado.getNombre());
        assertEquals("López", encuestado.getApellido());
        assertEquals("1234567890", encuestado.getCedula());
        assertEquals("carlos@email.com", encuestado.getCorreo());
        assertEquals("0999999999", encuestado.getTelefono());
        assertEquals("carlosUser", encuestado.getUsuario());
        assertEquals("secreta123", encuestado.getContrasenia());
    }

    @Test
    void testSetters() {
        encuestado.setEdad(30);
        encuestado.setGenero("F");
        encuestado.setEncuestaCompletada(true);

        assertEquals(30, encuestado.getEdad());
        assertEquals("F", encuestado.getGenero());
        assertTrue(encuestado.isEncuestaCompletada());
    }
}
