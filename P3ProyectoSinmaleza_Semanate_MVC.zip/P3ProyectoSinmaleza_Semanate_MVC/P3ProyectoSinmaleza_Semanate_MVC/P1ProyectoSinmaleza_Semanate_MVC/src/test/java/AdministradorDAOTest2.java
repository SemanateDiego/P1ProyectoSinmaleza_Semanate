import Modelo.Administrador;
import Modelo.DAO.AdministradorDAO;
import Modelo.DAO.ConexionMongoDB;
//import Modelo.Entidades.Administrador;
//import Modelo.Mongo.ConexionMongoDB;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.FindIterable;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdministradorDAOTest2 {

    private ConexionMongoDB mockConexion;
    private MongoCollection<Document> mockCollection;
    private FindIterable<Document> mockFindIterable;
    private AdministradorDAO administradorDAO;

    @BeforeEach
    public void setUp() {
        mockConexion = mock(ConexionMongoDB.class);
        mockCollection = mock(MongoCollection.class);
        mockFindIterable = mock(FindIterable.class);

        when(mockConexion.getCollection("Administradores")).thenReturn(mockCollection);

        administradorDAO = new AdministradorDAO(mockConexion);
    }

    @Test
    public void testGuardarInsertaAdministrador() {
        Administrador admin = new Administrador("", "", "", "", "", "", "","");
        admin.setRol("Admin");
        admin.setNombre("Juan");
        admin.setApellido("Perez");
        admin.setCedula("1234567890");
        admin.setCorreo("juan@mail.com");
        admin.setTelefono("0999999999");
        admin.setUsuario("juanp");
        admin.setContrasenia("1234");

        administradorDAO.guardar(admin);

        ArgumentCaptor<Document> captor = ArgumentCaptor.forClass(Document.class);
        verify(mockCollection).insertOne(captor.capture());
        Document doc = captor.getValue();

        assertEquals("Admin", doc.getString("rol"));
        assertEquals("Juan", doc.getString("nombre"));
        assertEquals("Perez", doc.getString("apellido"));
        assertEquals("1234567890", doc.getString("cedula"));
        assertEquals("juan@mail.com", doc.getString("correo"));
        assertEquals("0999999999", doc.getString("telefono"));
        assertEquals("juanp", doc.getString("usuario"));
        assertEquals("1234", doc.getString("contrasenia"));
    }

    @Test
    public void testExistePorCedulaRetornaTrue() {
        when(mockCollection.find(new Document("cedula", "123"))).thenReturn(mockFindIterable);
        when(mockFindIterable.first()).thenReturn(new Document("cedula", "123"));

        boolean existe = administradorDAO.existePorCedula("123");

        assertTrue(existe);
    }

    @Test
    public void testExistePorCedulaRetornaFalse() {
        when(mockCollection.find(new Document("cedula", "999"))).thenReturn(mockFindIterable);
        when(mockFindIterable.first()).thenReturn(null);

        boolean existe = administradorDAO.existePorCedula("999");

        assertFalse(existe);
    }
}
