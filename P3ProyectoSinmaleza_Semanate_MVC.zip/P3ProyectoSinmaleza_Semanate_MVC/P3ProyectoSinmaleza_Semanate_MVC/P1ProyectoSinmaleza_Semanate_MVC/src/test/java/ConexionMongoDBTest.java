import Modelo.DAO.ConexionMongoDB;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ConexionMongoDBTest {

    @Test
    public void testGetCollection() {
        ConexionMongoDB conexion = new ConexionMongoDB();
        MongoCollection<Document> collection = conexion.getCollection("TestColeccion");

        assertNotNull(collection);
        assertEquals("TestColeccion", collection.getNamespace().getCollectionName());

        conexion.cerrarConexion(); // Aumenta cobertura del método cerrarConexion()
    }

    @Test
    public void testGetDatabase() {
        ConexionMongoDB conexion = new ConexionMongoDB();
        MongoDatabase db = conexion.getDatabase();

        assertNotNull(db);
        assertEquals("P2ProyectoGrupal", db.getName());

        conexion.cerrarConexion();
    }
}
