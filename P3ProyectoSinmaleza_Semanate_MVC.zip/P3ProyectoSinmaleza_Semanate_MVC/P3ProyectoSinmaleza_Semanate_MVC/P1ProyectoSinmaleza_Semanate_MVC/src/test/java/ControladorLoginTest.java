import Controlador.ControladorLogin;
import Vista.InicioSesion;
import Servicio.LoginService;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ControladorLoginTest {

    static class InicioSesionTestable extends InicioSesion {
        InicioSesionTestable() {
            super();
            labenErrorUsuario = new JLabel();
            labenErrorContra = new JLabel();
            labenErrorUsuario.setVisible(false);
            labenErrorContra.setVisible(false);
            this.setVisible(true);
        }
    }

    InicioSesionTestable mockView;
    LoginService mockService;
    ControladorLogin controlador;

    @BeforeEach
    public void setUp() {
        mockView = new InicioSesionTestable();
        mockService = mock(LoginService.class);
        controlador = new ControladorLogin(mockView, mockService);
    }

    @Test
    public void testIngresarCamposVacios() throws Exception {
        mockView.txtUsuario.setText("");
        mockView.txtContra.setText("");

        SwingUtilities.invokeAndWait(() -> controlador.ingresar());

        assertTrue(mockView.labenErrorUsuario.isVisible());
        assertEquals("El usuario es obligatorio.", mockView.labenErrorUsuario.getText());

        assertTrue(mockView.labenErrorContra.isVisible());
        assertEquals("La contraseña es obligatoria.", mockView.labenErrorContra.getText());
    }

    @Test
    public void testIngresarCredencialesInvalidas() throws Exception {
        mockView.txtUsuario.setText("usuario");
        mockView.txtContra.setText("contrasena");

        when(mockService.validarCredenciales("usuario", "contrasena")).thenReturn(null);

        // Aquí NO mockeamos JOptionPane, sólo ejecutamos el método
        SwingUtilities.invokeAndWait(() -> controlador.ingresar());

        // Comprobamos que no hay mensajes visibles de error de campo, 
        // pero el diálogo no lo probamos para evitar el error
        assertFalse(mockView.labenErrorUsuario.isVisible());
        assertFalse(mockView.labenErrorContra.isVisible());

        // No se puede verificar showMessageDialog sin mockStatic,
        // así que omitimos esa verificación para evitar errores en el test.
    }
}
