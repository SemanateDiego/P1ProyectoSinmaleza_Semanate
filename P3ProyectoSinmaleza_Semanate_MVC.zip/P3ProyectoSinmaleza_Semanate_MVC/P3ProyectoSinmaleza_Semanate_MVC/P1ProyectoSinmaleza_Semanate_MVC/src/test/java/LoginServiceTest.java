import Modelo.Administrador;
import Modelo.DAO.ValidarUsuario;
import Modelo.Encuestado;
import Servicio.LoginService;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class LoginServiceTest {

    private ValidarUsuario validarUsuarioMock;
    private LoginService loginService;

    @BeforeEach
    public void setUp() {
        validarUsuarioMock = mock(ValidarUsuario.class);
        loginService = new LoginService(validarUsuarioMock);
    }

    @Test
    public void testValidarCredenciales_nullOrEmptyUsuarioContrasena() {
        assertNull(loginService.validarCredenciales(null, "pass"));
        assertNull(loginService.validarCredenciales("user", null));
        assertNull(loginService.validarCredenciales("", "pass"));
        assertNull(loginService.validarCredenciales("user", ""));
    }

    @Test
    public void testValidarCredenciales_validoRetornaDocumento() {
        Document docMock = new Document("usuario", "user").append("contrasenia", "pass");
        when(validarUsuarioMock.validarUsuario("user", "pass")).thenReturn(docMock);

        Document resultado = loginService.validarCredenciales("user", "pass");

        assertNotNull(resultado);
        assertEquals("user", resultado.getString("usuario"));
        verify(validarUsuarioMock, times(1)).validarUsuario("user", "pass");
    }

    @Test
    public void testObtenerStringSeguro() {
        Document doc = new Document();
        doc.append("clave1", "valor1");
        doc.append("clave2", null);

        assertEquals("valor1", loginService.obtenerStringSeguro(doc, "clave1"));
        assertEquals("", loginService.obtenerStringSeguro(doc, "clave2"));
        assertEquals("", loginService.obtenerStringSeguro(doc, "claveNoExiste"));
        assertEquals("", loginService.obtenerStringSeguro(null, "cualquierClave"));
    }

    @Test
    public void testCrearAdministrador() {
        Document doc = new Document()
                .append("rol", "Admin")
                .append("nombre", "Carlos")
                .append("apellido", "Lopez")
                .append("cedula", "0123456789")
                .append("correo", "carlos@mail.com")
                .append("telefono", "0999888777")
                .append("usuario", "carlos")
                .append("contrasenia", "1234");

        Administrador admin = loginService.crearAdministrador(doc);

        assertEquals("Admin", admin.getRol());
        assertEquals("Carlos", admin.getNombre());
        assertEquals("Lopez", admin.getApellido());
        assertEquals("0123456789", admin.getCedula());
        assertEquals("carlos@mail.com", admin.getCorreo());
        assertEquals("0999888777", admin.getTelefono());
        assertEquals("carlos", admin.getUsuario());
        assertEquals("1234", admin.getContrasenia());
    }

    @Test
    public void testCrearEncuestado() {
        Document doc = new Document()
                .append("edad", 40)
                .append("genero", "M")
                .append("encuestaCompletada", true)
                .append("nombre", "Luis")
                .append("apellido", "Martinez")
                .append("cedula", "0987654321")
                .append("correo", "luis@mail.com")
                .append("telefono", "0999777666")
                .append("usuario", "luism")
                .append("contrasenia", "pass567");

        Encuestado encuestado = loginService.crearEncuestado(doc);

        assertEquals(40, encuestado.getEdad());
        assertEquals("M", encuestado.getGenero());
        assertTrue(encuestado.isEncuestaCompletada());
        assertEquals("Luis", encuestado.getNombre());
        assertEquals("Martinez", encuestado.getApellido());
        assertEquals("0987654321", encuestado.getCedula());
        assertEquals("luis@mail.com", encuestado.getCorreo());
        assertEquals("0999777666", encuestado.getTelefono());
        assertEquals("luism", encuestado.getUsuario());
        assertEquals("pass567", encuestado.getContrasenia());
    }
}

