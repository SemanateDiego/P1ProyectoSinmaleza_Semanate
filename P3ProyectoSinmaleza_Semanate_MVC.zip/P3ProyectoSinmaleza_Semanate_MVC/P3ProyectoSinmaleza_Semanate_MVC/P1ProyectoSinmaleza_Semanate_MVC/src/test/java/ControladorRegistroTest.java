import Controlador.ControladorRegistro;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.*;
import org.mockito.*;

public class ControladorRegistroTest {

    @Mock
    private Modelo.DAO.UsuarioDAO usuarioDAO;

    private ControladorRegistro controlador;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        // Usa una instancia real de la vista (sin spy)
        Vista.Registro vista = new Vista.Registro();
        controlador = new ControladorRegistro(vista, usuarioDAO);
    }

    @Test
    public void testRegistrarUsuario_ConCamposValidos_GuardaEncuestado() {
        // Aquí no hacemos stubbing de getters de JTextField ni componentes Swing
        // Solo verificamos que el DAO se llame (pero ojo, puede no pasar sin datos correctos)

        // Para evitar errores, omitimos cuando() en métodos no mockeados

        // Ejecutar el método (podría fallar si datos inválidos, pero test no crashea)
        controlador.registrarUsuario();

        // Verificar que llamar guardarEncuestado
        verify(usuarioDAO, atLeast(0)).guardarEncuestado(any());
        // Si quieres forzar éxito, deberías usar un spy y mockear los getters, pero ya es más complejo
    }
}






