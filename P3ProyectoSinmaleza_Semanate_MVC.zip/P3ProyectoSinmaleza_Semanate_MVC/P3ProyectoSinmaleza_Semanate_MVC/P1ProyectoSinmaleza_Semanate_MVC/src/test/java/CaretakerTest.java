import PatronesDiseño.Caretaker;
import PatronesDiseño.Memento;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class CaretakerTest {

    private Caretaker caretaker;

    @BeforeEach
    public void setUp() {
        caretaker = new Caretaker();
    }

    private Memento crearMementoConEstado(String preguntaTexto) {
        Document doc = new Document("pregunta", preguntaTexto);
        return new Memento(List.of(doc));
    }

    @Test
    public void testGuardarYDeshacer() {
        Memento m1 = crearMementoConEstado("Estado1");
        Memento m2 = crearMementoConEstado("Estado2");

        caretaker.guardar(m1);
        caretaker.guardar(m2);

        // Primer deshacer debería retornar m2
        Memento deshacer1 = caretaker.deshacer();
        assertEquals("Estado2", deshacer1.getEstado().get(0).getString("pregunta"));

        // Segundo deshacer debería retornar m1
        Memento deshacer2 = caretaker.deshacer();
        assertEquals("Estado1", deshacer2.getEstado().get(0).getString("pregunta"));

        // Tercer deshacer (sin más elementos) debería retornar null
        assertNull(caretaker.deshacer());
    }

    @Test
    public void testGuardarYLuegoRehacer() {
        Memento m1 = crearMementoConEstado("Estado1");
        Memento m2 = crearMementoConEstado("Estado2");

        caretaker.guardar(m1);
        caretaker.guardar(m2);

        caretaker.deshacer(); // m2
        caretaker.deshacer(); // m1

        Memento rehacer1 = caretaker.rehacer();
        assertEquals("Estado1", rehacer1.getEstado().get(0).getString("pregunta"));

        Memento rehacer2 = caretaker.rehacer();
        assertEquals("Estado2", rehacer2.getEstado().get(0).getString("pregunta"));

        assertNull(caretaker.rehacer());
    }

    @Test
    public void testGuardarLimpiaRedo() {
        Memento m1 = crearMementoConEstado("Estado1");
        Memento m2 = crearMementoConEstado("Estado2");
        Memento m3 = crearMementoConEstado("Estado3");

        caretaker.guardar(m1);
        caretaker.guardar(m2);

        caretaker.deshacer(); // redo contiene m2

        caretaker.guardar(m3); // guarda nuevo → limpia redo

        assertNull(caretaker.rehacer());
    }
}

