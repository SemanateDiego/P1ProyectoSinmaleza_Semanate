import Modelo.Validaciones.ValidadorEdad;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ValidadorEdadTest {

    private ValidadorEdad validador;

    @BeforeEach
    void setUp() {
        validador = new ValidadorEdad(18); // Edad mínima establecida
    }

    @Test
    void testEdadValida() {
        assertTrue(validador.validar(20), "Debe aceptar edad igual o mayor a la mínima");
    }

    @Test
    void testEdadExactamenteMinima() {
        assertTrue(validador.validar(18), "Debe aceptar edad igual a la mínima");
    }

    @Test
    void testEdadInvalida() {
        assertFalse(validador.validar(16), "Debe rechazar edad menor a la mínima");
        assertEquals("La edad mínima es 18", validador.getMensajeError(), "Debe mostrar el mensaje de error correcto");
    }
}

