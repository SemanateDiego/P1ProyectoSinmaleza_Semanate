import Modelo.Administrador;
import Modelo.Encuestado;
import Modelo.DAO.ConexionMongoDB;
import Servicio.AdminService;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.result.DeleteResult;
import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdminServiceTest {

    private ConexionMongoDB conexionMock;
    private MongoCollection<Document> coleccionMock;
    private AdminService adminService;

    @BeforeEach
    public void setUp() {
        conexionMock = mock(ConexionMongoDB.class);
        coleccionMock = mock(MongoCollection.class);
        adminService = new AdminService(conexionMock);
    }

    @Test
    public void testCargarAdministradores_conAdminNoNulo() {
        Administrador admin = new Administrador("", "", "", "", "", "", "", "");
        List<Administrador> resultado = adminService.cargarAdministradores(admin);
        assertEquals(1, resultado.size());
        assertSame(admin, resultado.get(0));
    }

    @Test
    public void testCargarAdministradores_conAdminNulo() {
        List<Administrador> resultado = adminService.cargarAdministradores(null);
        assertTrue(resultado.isEmpty());
    }

    @Test
    public void testCargarEncuestados_retornaListaEncuestados() {
        // Datos simulados
        List<Document> documentosSimulados = new ArrayList<>();
        Document doc = new Document()
                .append("edad", 30)
                .append("genero", "F")
                .append("encuestaCompletada", true)
                .append("nombre", "Maria")
                .append("apellido", "Gomez")
                .append("cedula", "9876543210")
                .append("correo", "maria@mail.com")
                .append("telefono", "0999999999")
                .append("usuario", "mariag")
                .append("contrasenia", "pass123");
        documentosSimulados.add(doc);

        // Mock para FindIterable
        FindIterable<Document> findIterableMock = mock(FindIterable.class);
        when(conexionMock.getCollection("Encuestados")).thenReturn(coleccionMock);
        when(coleccionMock.find()).thenReturn(findIterableMock);

        // Simular el método into para que agregue los documentos simulados
        when(findIterableMock.into(any(List.class))).thenAnswer(invocation -> {
            List<Document> listaDestino = invocation.getArgument(0);
            listaDestino.addAll(documentosSimulados);
            return listaDestino;
        });

        List<Encuestado> resultado = adminService.cargarEncuestados();

        assertEquals(1, resultado.size());
        Encuestado e = resultado.get(0);
        assertEquals(30, e.getEdad());
        assertEquals("Maria", e.getNombre());
        assertEquals("mariag", e.getUsuario());
    }

    @Test
    public void testActualizarEncuestadoEnBD_llamaUpdateOne() {
        when(conexionMock.getCollection("Encuestados")).thenReturn(coleccionMock);

        Encuestado e = new Encuestado(0, "", true, "", "", "", "", "", "", "");
        e.setCedula("123456");
        e.setNombre("Luis");
        e.setApellido("Perez");
        e.setCorreo("luis@mail.com");
        e.setTelefono("0998887777");
        e.setUsuario("luisp");
        e.setContrasenia("mypassword");

        adminService.actualizarEncuestadoEnBD(e);

        ArgumentCaptor<Document> filtroCaptor = ArgumentCaptor.forClass(Document.class);
        ArgumentCaptor<Document> updateCaptor = ArgumentCaptor.forClass(Document.class);

        verify(coleccionMock).updateOne(filtroCaptor.capture(), updateCaptor.capture());

        Document filtro = filtroCaptor.getValue();
        assertEquals("123456", filtro.getString("cedula"));

        Document update = updateCaptor.getValue();
        assertTrue(update.containsKey("$set"));
        Document datos = (Document) update.get("$set");
        assertEquals("Luis", datos.getString("nombre"));
        assertEquals("luisp", datos.getString("usuario"));
    }

    @Test
    public void testEliminarEncuestadoPorCedula_retornaTrueSiEliminado() {
        DeleteResult deleteResultMock = mock(DeleteResult.class);
        when(deleteResultMock.getDeletedCount()).thenReturn(1L);

        when(conexionMock.getCollection("Encuestados")).thenReturn(coleccionMock);
        when(coleccionMock.deleteOne(any(Document.class))).thenReturn(deleteResultMock);

        boolean resultado = adminService.eliminarEncuestadoPorCedula("123456");

        assertTrue(resultado);
        verify(coleccionMock).deleteOne(any(Document.class));
    }

    @Test
    public void testEliminarEncuestadoPorCedula_retornaFalseSiNoEliminado() {
        DeleteResult deleteResultMock = mock(DeleteResult.class);
        when(deleteResultMock.getDeletedCount()).thenReturn(0L);

        when(conexionMock.getCollection("Encuestados")).thenReturn(coleccionMock);
        when(coleccionMock.deleteOne(any(Document.class))).thenReturn(deleteResultMock);

        boolean resultado = adminService.eliminarEncuestadoPorCedula("123456");

        assertFalse(resultado);
    }

    @Test
    public void testSafeGet_retornaValorCorrecto() {
        Document doc = new Document();
        doc.append("campo1", "valor1");
        doc.append("campo2", null);

        assertEquals("valor1", adminService.safeGet(doc, "campo1"));
        assertEquals("", adminService.safeGet(doc, "campo2"));
        assertEquals("", adminService.safeGet(doc, "campoNoExiste"));
    }

    @Test
    public void testExportarUsuariosCSV_retornaTrueYArchivoGenerado() throws Exception {
        List<Document> docsAdmins = new ArrayList<>();
        docsAdmins.add(new Document()
                .append("nombre", "AdminTest")
                .append("apellido", "TestApellido")
                .append("cedula", "111222333")
                .append("correo", "admin@test.com")
                .append("telefono", "0999999999")
                .append("usuario", "admintest"));

        FindIterable<Document> findIterableMock = mock(FindIterable.class);
        when(conexionMock.getCollection("Administradores")).thenReturn(coleccionMock);
        when(coleccionMock.find()).thenReturn(findIterableMock);
        when(findIterableMock.into(any(List.class))).thenAnswer(invocation -> {
            List<Document> targetList = invocation.getArgument(0);
            targetList.addAll(docsAdmins);
            return targetList;
        });

        List<Administrador> admins = new ArrayList<>();
        admins.add(new Administrador("", "", "", "", "", "", "", ""));

        List<Encuestado> encuestados = new ArrayList<>();
        Encuestado e = new Encuestado(0, "", true, "", "", "", "", "", "", "");
        e.setNombre("EncuestadoTest");
        e.setApellido("ApellidoEnc");
        e.setCedula("444555666");
        e.setCorreo("enc@test.com");
        e.setTelefono("0888888888");
        e.setUsuario("encuestado");
        encuestados.add(e);

        boolean resultado = adminService.exportarUsuariosCSV(admins, encuestados);

        assertTrue(resultado);

        File archivo = new File("usuarios_registrados.csv");
        assertTrue(archivo.exists());

        // Elimina archivo generado para no dejar basura
        archivo.delete();
    }
}


