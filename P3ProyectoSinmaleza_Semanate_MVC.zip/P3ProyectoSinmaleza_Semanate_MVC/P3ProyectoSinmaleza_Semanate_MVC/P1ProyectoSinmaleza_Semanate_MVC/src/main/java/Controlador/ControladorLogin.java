package Controlador;

import Modelo.Administrador;
import Modelo.Encuestado;
import Modelo.DAO.ValidarUsuario;
import Servicio.LoginService;
import Vista.InicioSesion;
import Vista.Registro;
import Vista.Admin;
import Vista.VistaEncuesta;
import org.bson.Document;

import javax.swing.*;

public class ControladorLogin {
    private final InicioSesion loginView;
    private final LoginService loginService;

    public ControladorLogin(InicioSesion loginView) {
        this(loginView, new LoginService(new ValidarUsuario()));
    }

    public ControladorLogin(InicioSesion loginView, LoginService loginService) {
        this.loginView = loginView;
        this.loginService = loginService;

        this.loginView.btnInicioSesion.addActionListener(e -> ingresar());
        this.loginView.btnRegistro.addActionListener(e -> abrirRegistro());
        ocultarErrores();
    }

    public void ingresar() {
        ocultarErrores();
        String usuario = loginView.txtUsuario.getText().trim();
        String contrasena = new String(loginView.txtContra.getPassword()).trim();

        boolean valido = true;
        if (usuario.isEmpty()) {
            loginView.labenErrorUsuario.setText("El usuario es obligatorio.");
            loginView.labenErrorUsuario.setVisible(true);
            valido = false;
        }
        if (contrasena.isEmpty()) {
            loginView.labenErrorContra.setText("La contraseña es obligatoria.");
            loginView.labenErrorContra.setVisible(true);
            valido = false;
        }
        if (!valido) return;

        Document datosUsuario = loginService.validarCredenciales(usuario, contrasena);
        if (datosUsuario != null) {
            JOptionPane.showMessageDialog(loginView, "Inicio de sesión exitoso.");
            redirigirSegunRolConDatos(datosUsuario);
        } else {
            JOptionPane.showMessageDialog(loginView, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void redirigirSegunRolConDatos(Document datosUsuario) {
        loginView.dispose();
        String rol = loginService.obtenerStringSeguro(datosUsuario, "rol");

        if ("Administrador".equalsIgnoreCase(rol)) {
            Administrador admin = loginService.crearAdministrador(datosUsuario);
            new ControladorAdmin(new Admin(), admin).iniciar();
        } else if ("Encuestado".equalsIgnoreCase(rol)) {
            Encuestado encuestado = loginService.crearEncuestado(datosUsuario);
            new ControladorEncuestado(new VistaEncuesta(), encuestado).iniciar();
        } else {
            JOptionPane.showMessageDialog(null, "Rol desconocido. Contacte al administrador.", "Error", JOptionPane.ERROR_MESSAGE);
            loginView.setVisible(true);
        }
    }

    public void abrirRegistro() {
        loginView.setVisible(false);
        new ControladorRegistro(new Registro()).iniciar();
    }

    public void ocultarErrores() {
        loginView.labenErrorUsuario.setVisible(false);
        loginView.labenErrorContra.setVisible(false);
    }

    public void iniciar() {
        loginView.setVisible(true);
    }
}

