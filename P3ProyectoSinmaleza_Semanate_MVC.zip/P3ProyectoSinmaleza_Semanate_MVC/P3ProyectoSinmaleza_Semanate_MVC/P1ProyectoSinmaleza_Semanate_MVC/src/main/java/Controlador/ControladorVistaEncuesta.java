package Controlador;

import Vista.VistaEncuesta;
import Modelo.Encuestado;
import PatronesDiseño.AgregarPreguntaCommand;
import PatronesDiseño.Caretaker;
import PatronesDiseño.Command;
import PatronesDiseño.Memento;
import Vista.InicioSesion;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.util.*;

public class ControladorVistaEncuesta {
    private final VistaEncuesta vista;
    private final boolean esAdmin;
    private final MongoDatabase db;
    private Encuestado encuestado;

    private final List<Document> preguntasAdmin = new ArrayList<>();
    private int numeroPreguntaAdmin = 1;

    private List<Document> preguntasEncuestado = new ArrayList<>();
    private int indicePreguntaEncuestado = 0;
    private String encuestaSeleccionada;

    private final ButtonGroup grupoOpciones = new ButtonGroup();
    private final Map<Integer, String> respuestas = new HashMap<>();
    private final Set<String> encuestasRespondidas = new HashSet<>();
    //Patrones de diseño
    private final Caretaker caretaker = new Caretaker();
    private final Stack<Command> historial = new Stack<>();


    public ControladorVistaEncuesta(VistaEncuesta vista, boolean esAdmin, MongoDatabase db, Encuestado encuestado) {
        this.vista = vista;
        this.esAdmin = esAdmin;
        this.db = db;
        this.encuestado = encuestado;

        grupoOpciones.add(vista.rbtPregunta1);
        grupoOpciones.add(vista.rbtPregunta2);
        grupoOpciones.add(vista.rbtPregunta3);
        grupoOpciones.add(vista.rbtPregunta4);
        // Botón Undo
        vista.btnUndo.addActionListener(e -> {
            if (!historial.isEmpty()) {
                // Guarda el estado actual antes de deshacer
                caretaker.guardar(new Memento(new ArrayList<>(preguntasAdmin)));

                Command comando = historial.pop();
                comando.deshacer();

                JOptionPane.showMessageDialog(vista, "Se deshizo la última acción.");
            } else {
                JOptionPane.showMessageDialog(vista, "No hay acciones para deshacer.");
            }
        });

        // Botón Redo
        vista.btnRedo.addActionListener(e -> {
            Memento m = caretaker.rehacer();
            if (m != null) {
                preguntasAdmin.clear();
                preguntasAdmin.addAll(m.getEstado());
                numeroPreguntaAdmin = preguntasAdmin.size() + 1;
                vista.labelPregunta.setText("Pregunta " + numeroPreguntaAdmin);

                JOptionPane.showMessageDialog(vista, "Se rehizo la acción.");
            } else {
                JOptionPane.showMessageDialog(vista, "No hay acciones para rehacer.");
            }
        });


        inicializarVista();
        agregarEventos();
    }

    private void inicializarVista() {
        limpiarErrores();
        limpiarCamposAdmin();
        limpiarCamposEncuestado();

        if (esAdmin) {
            vista.txtNombreDeEncuesta.setVisible(true);
            vista.txtPregunta.setVisible(true);
            vista.txtPregunta1.setVisible(true);
            vista.txtPregunta2.setVisible(true);
            vista.txtPregunta3.setVisible(true);
            vista.txtPregunta4.setVisible(true);

            vista.btnGuardar.setVisible(true);
            vista.btnSiguiente.setVisible(true);
            vista.btnEnviar.setVisible(false);
            vista.cbxNombreDeEncuesta.setVisible(false);

            vista.rbtPregunta1.setVisible(false);
            vista.rbtPregunta2.setVisible(false);
            vista.rbtPregunta3.setVisible(false);
            vista.rbtPregunta4.setVisible(false);

            habilitarCamposAdmin(false);
            vista.labelPregunta.setText("Ingrese el nombre de la encuesta");
        } else {
            vista.txtNombreDeEncuesta.setVisible(false);
            vista.txtPregunta.setVisible(false);
            vista.txtPregunta1.setVisible(false);
            vista.txtPregunta2.setVisible(false);
            vista.txtPregunta3.setVisible(false);
            vista.txtPregunta4.setVisible(false);

            vista.btnGuardar.setVisible(false);
            vista.btnSiguiente.setVisible(true);
            vista.btnEnviar.setVisible(true);
            vista.cbxNombreDeEncuesta.setVisible(true);

            vista.rbtPregunta1.setVisible(true);
            vista.rbtPregunta2.setVisible(true);
            vista.rbtPregunta3.setVisible(true);
            vista.rbtPregunta4.setVisible(true);

            cargarEncuestasDisponibles();
        }
    }

    private void agregarEventos() {
        if (esAdmin) {
            vista.txtNombreDeEncuesta.getDocument().addDocumentListener(new DocumentListener() {
                public void insertUpdate(DocumentEvent e) { validarNombreEncuestaAdmin(); }
                public void removeUpdate(DocumentEvent e) { validarNombreEncuestaAdmin(); }
                public void changedUpdate(DocumentEvent e) { validarNombreEncuestaAdmin(); }
            });

            vista.btnSiguiente.addActionListener(e -> agregarPreguntaAdmin());
            vista.btnGuardar.addActionListener(e -> guardarEncuestaAdmin());
            vista.btnCancelar.addActionListener(e -> cerrarVista());
        } else {
            vista.cbxNombreDeEncuesta.addActionListener(e -> cargarPreguntasEncuestado());
            vista.btnEnviar.addActionListener(e -> enviarRespuestasEncuestado());
            vista.btnCancelar.addActionListener(e -> regresarALogin());
            vista.btnSiguiente.addActionListener(e -> siguientePreguntaEncuestado());
        }
    }

    private void validarNombreEncuestaAdmin() {
        String nombre = vista.txtNombreDeEncuesta.getText().trim();
        boolean habilitar = !nombre.isEmpty();
        habilitarCamposAdmin(habilitar);

        vista.labelPregunta.setText(habilitar ? "Pregunta " + numeroPreguntaAdmin : "Ingrese el nombre de la encuesta");
        if (!habilitar) limpiarCamposAdmin();
    }

    private void habilitarCamposAdmin(boolean habilitar) {
        vista.txtPregunta.setEnabled(habilitar);
        vista.txtPregunta1.setEnabled(habilitar);
        vista.txtPregunta2.setEnabled(habilitar);
        vista.txtPregunta3.setEnabled(habilitar);
        vista.txtPregunta4.setEnabled(habilitar);
        vista.btnSiguiente.setEnabled(habilitar);
    }

    private void agregarPreguntaAdmin() {
        limpiarErrores();

        if (vista.txtPregunta.getText().trim().isEmpty()) {
            vista.labelErrorNombrePregunta.setText("La pregunta es obligatoria.");
            vista.labelErrorNombrePregunta.setVisible(true);
            return;
        }

        Document preguntaDoc = new Document("numero", numeroPreguntaAdmin)
            .append("pregunta", vista.txtPregunta.getText().trim())
            .append("opciones", List.of(
                vista.txtPregunta1.getText().trim(),
                vista.txtPregunta2.getText().trim(),
                vista.txtPregunta3.getText().trim(),
                vista.txtPregunta4.getText().trim()
            ));

        // 🛠️ Guardar una COPIA del estado ACTUAL antes de modificarlo
        caretaker.guardar(new Memento(new ArrayList<>(preguntasAdmin)));

        // Ejecutar comando
        Command comando = new AgregarPreguntaCommand(this, preguntaDoc);
        comando.ejecutar();

        // Guardar comando en historial para deshacer
        historial.push(comando);

        numeroPreguntaAdmin++;
        vista.labelPregunta.setText("Pregunta " + numeroPreguntaAdmin);
        limpiarCamposAdmin();

        JOptionPane.showMessageDialog(vista, "Pregunta agregada correctamente.");
    }


    private void guardarEncuestaAdmin() {
        if (vista.txtNombreDeEncuesta.getText().trim().isEmpty() || preguntasAdmin.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Complete el nombre y al menos una pregunta.");
            return;
        }

        Document encuestaDoc = new Document("nombreEncuesta", vista.txtNombreDeEncuesta.getText().trim())
                .append("preguntas", preguntasAdmin);

        db.getCollection("Encuestas").insertOne(encuestaDoc);
        JOptionPane.showMessageDialog(vista, "Encuesta guardada correctamente.");
        vista.dispose();
    }

    private void cargarEncuestasDisponibles() {
        MongoCollection<Document> encuestas = db.getCollection("Encuestas");
        MongoCollection<Document> respuestas = db.getCollection("Respuestas");

        List<Document> todasEncuestas = encuestas.find().into(new ArrayList<>());
        List<Document> yaRespondidas = respuestas.find(new Document("cedulaEncuestado", encuestado.getCedula())).into(new ArrayList<>());

        encuestasRespondidas.clear();
        for (Document doc : yaRespondidas) {
            encuestasRespondidas.add(doc.getString("nombreEncuesta"));
        }

        vista.cbxNombreDeEncuesta.removeAllItems();
        for (Document encuesta : todasEncuestas) {
            String nombre = encuesta.getString("nombreEncuesta");
            if (!encuestasRespondidas.contains(nombre)) {
                vista.cbxNombreDeEncuesta.addItem(nombre);
            }
        }

        if (vista.cbxNombreDeEncuesta.getItemCount() == 0) {
            JOptionPane.showMessageDialog(vista, "No tienes encuestas pendientes. Vuelve más tarde.");
            regresarALogin();
        } else {
            vista.cbxNombreDeEncuesta.setSelectedIndex(0);
            cargarPreguntasEncuestado();
        }
    }

    private void cargarPreguntasEncuestado() {
        encuestaSeleccionada = (String) vista.cbxNombreDeEncuesta.getSelectedItem();
        if (encuestaSeleccionada == null) return;

        Document filtro = new Document("nombreEncuesta", encuestaSeleccionada);
        Document encuestaDoc = db.getCollection("Encuestas").find(filtro).first();

        if (encuestaDoc == null) return;

        preguntasEncuestado = (List<Document>) encuestaDoc.get("preguntas");
        indicePreguntaEncuestado = 0;
        respuestas.clear();

        mostrarPreguntaEncuestado(indicePreguntaEncuestado);
    }

    private void mostrarPreguntaEncuestado(int indice) {
        if (indice >= preguntasEncuestado.size()) return;

        Document pregunta = preguntasEncuestado.get(indice);
        vista.labelPregunta.setText("Pregunta " + (indice + 1) + ": " + pregunta.getString("pregunta"));

        List<String> opciones = (List<String>) pregunta.get("opciones");

        vista.rbtPregunta1.setText(opciones.get(0));
        vista.rbtPregunta2.setText(opciones.get(1));
        vista.rbtPregunta3.setText(opciones.get(2));
        vista.rbtPregunta4.setText(opciones.get(3));

        grupoOpciones.clearSelection();

        vista.btnEnviar.setEnabled(indice == preguntasEncuestado.size() - 1);
        vista.btnSiguiente.setEnabled(indice < preguntasEncuestado.size() - 1);
    }

    private void siguientePreguntaEncuestado() {
        if (!validarSeleccion()) return;

        respuestas.put(indicePreguntaEncuestado, obtenerRespuesta());
        indicePreguntaEncuestado++;
        mostrarPreguntaEncuestado(indicePreguntaEncuestado);
    }

    public boolean validarSeleccion() {
        if (!vista.rbtPregunta1.isSelected() && !vista.rbtPregunta2.isSelected() &&
            !vista.rbtPregunta3.isSelected() && !vista.rbtPregunta4.isSelected()) {
            JOptionPane.showMessageDialog(vista, "Seleccione una opción para continuar.");
            return false;
        }
        return true;
    }

    public String obtenerRespuesta() {
        if (vista.rbtPregunta1.isSelected()) return vista.rbtPregunta1.getText();
        if (vista.rbtPregunta2.isSelected()) return vista.rbtPregunta2.getText();
        if (vista.rbtPregunta3.isSelected()) return vista.rbtPregunta3.getText();
        if (vista.rbtPregunta4.isSelected()) return vista.rbtPregunta4.getText();
        return "";
    }

    private void enviarRespuestasEncuestado() {
        if (!validarSeleccion()) return;

        respuestas.put(indicePreguntaEncuestado, obtenerRespuesta());

        List<String> respuestasFinales = new ArrayList<>();
        for (int i = 0; i < preguntasEncuestado.size(); i++) {
            String pregunta = preguntasEncuestado.get(i).getString("pregunta");
            respuestasFinales.add(pregunta + ": " + respuestas.get(i));
        }

        Document respuestaDoc = new Document("cedulaEncuestado", encuestado.getCedula())
                .append("nombreEncuesta", encuestaSeleccionada)
                .append("respuestas", respuestasFinales);

        db.getCollection("Respuestas").insertOne(respuestaDoc);

        int opcion = JOptionPane.showConfirmDialog(vista, "Gracias por responder. ¿Deseas responder otra encuesta?", "Encuesta finalizada", JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            cargarEncuestasDisponibles();
        } else {
            regresarALogin();
        }
    }

    private void limpiarCamposAdmin() {
        vista.txtPregunta.setText("");
        vista.txtPregunta1.setText("");
        vista.txtPregunta2.setText("");
        vista.txtPregunta3.setText("");
        vista.txtPregunta4.setText("");
    }

    private void limpiarCamposEncuestado() {
        grupoOpciones.clearSelection();
        limpiarErrores();
    }

    private void limpiarErrores() {
        vista.labelErrorNombrePregunta.setVisible(false);
        vista.labelErrorPregunta1.setVisible(false);
        vista.labelErrorPregunta2.setVisible(false);
        vista.labelErrorPregunta3.setVisible(false);
        vista.labelErrorPregunta4.setVisible(false);
    }

    private void cerrarVista() {
        vista.setVisible(false);
        InicioSesion login = new InicioSesion();
        ControladorLogin controlador = new ControladorLogin(login);
        controlador.iniciar();
    }

    private void regresarALogin() {
        vista.setVisible(false);
        InicioSesion login = new InicioSesion();
        ControladorLogin controlador = new ControladorLogin(login);
        controlador.iniciar();
    }

    public void iniciar() {
        vista.setVisible(true);
    }
    
    //Patrones de diseño
    // Métodos que ejecuta el comando:
    public void agregarPreguntaDesdeCommand(Document pregunta) {
        preguntasAdmin.add(pregunta);
    }

    public void eliminarUltimaPreguntaDesdeCommand() {
        if (!preguntasAdmin.isEmpty()) {
            preguntasAdmin.remove(preguntasAdmin.size() - 1);
            numeroPreguntaAdmin--;
            vista.labelPregunta.setText("Pregunta " + numeroPreguntaAdmin);
        }
    }

}
