package Controlador;

import Vista.VistaEncuesta;
import Modelo.Encuestado;
import Modelo.DAO.ConexionMongoDB;
import Vista.InicioSesion;
import javax.swing.*;
import java.util.*;

import org.bson.Document;
import com.mongodb.client.MongoCollection;

public class ControladorEncuestado {
    private VistaEncuesta vista;
    private Encuestado encuestado;
    private ConexionMongoDB conexion;
    private List<Document> listaPreguntas;
    private String encuestaSeleccionada;
    private int preguntaActual = 0;

    private Map<Integer, String> respuestasMap = new HashMap<>();
    private Set<String> encuestasRespondidas = new HashSet<>();

    private final ButtonGroup grupoOpciones = new ButtonGroup();

    public ControladorEncuestado(VistaEncuesta vista, Encuestado encuestado) {
        this.vista = vista;
        this.encuestado = encuestado;
        this.conexion = new ConexionMongoDB();

        grupoOpciones.add(vista.rbtPregunta1);
        grupoOpciones.add(vista.rbtPregunta2);
        grupoOpciones.add(vista.rbtPregunta3);
        grupoOpciones.add(vista.rbtPregunta4);

        configurarVista();

        // Si no hay encuestas disponibles, cerrar programa
        if (!cargarEncuestasDisponibles()) {
            vista.dispose();
            System.exit(0);
            return;
        }

        vista.cbxNombreDeEncuesta.addActionListener(e -> seleccionarEncuesta());
        vista.btnEnviar.addActionListener(e -> enviarRespuestas());
        vista.btnCancelar.addActionListener(e -> cancelar());
        vista.btnSiguiente.addActionListener(e -> siguientePregunta());
    }

    private void configurarVista() {
        vista.txtNombreDeEncuesta.setVisible(false);
        vista.txtPregunta.setVisible(false);
        vista.txtPregunta1.setVisible(false);
        vista.txtPregunta2.setVisible(false);
        vista.txtPregunta3.setVisible(false);
        vista.txtPregunta4.setVisible(false);

        vista.rbtPregunta1.setVisible(true);
        vista.rbtPregunta2.setVisible(true);
        vista.rbtPregunta3.setVisible(true);
        vista.rbtPregunta4.setVisible(true);

        ocultarLabelsError();

        vista.labelPregunta.setText("");

        vista.btnGuardar.setVisible(false);
        vista.btnEnviar.setEnabled(false);
        vista.btnSiguiente.setEnabled(true);
        vista.btnSiguiente.setVisible(true);
        vista.btnEnviar.setVisible(true);
    }

    private void ocultarLabelsError() {
        vista.labelErrorNombrePregunta.setVisible(false);
        vista.labelErrorPregunta1.setVisible(false);
        vista.labelErrorPregunta2.setVisible(false);
        vista.labelErrorPregunta3.setVisible(false);
        vista.labelErrorPregunta4.setVisible(false);
    }

    private boolean cargarEncuestasDisponibles() {
        MongoCollection<Document> coleccionEncuestas = conexion.getCollection("Encuestas");
        List<Document> documentosEncuestas = coleccionEncuestas.find().into(new ArrayList<>());

        MongoCollection<Document> coleccionRespuestas = conexion.getCollection("Respuestas");
        Document filtroRespuestas = new Document("cedulaEncuestado", encuestado.getCedula());
        List<Document> respuestasPrevias = coleccionRespuestas.find(filtroRespuestas).into(new ArrayList<>());

        encuestasRespondidas.clear();
        for (Document docResp : respuestasPrevias) {
            encuestasRespondidas.add(docResp.getString("nombreEncuesta"));
        }

        vista.cbxNombreDeEncuesta.removeAllItems();

        for (Document encuestaDoc : documentosEncuestas) {
            String nombreEncuesta = encuestaDoc.getString("nombreEncuesta");
            if (!encuestasRespondidas.contains(nombreEncuesta)) {
                vista.cbxNombreDeEncuesta.addItem(nombreEncuesta);
            }
        }

        if (vista.cbxNombreDeEncuesta.getItemCount() > 0) {
            vista.cbxNombreDeEncuesta.setSelectedIndex(0);
            cargarPreguntasDeEncuesta();
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "No tienes encuestas pendientes por responder. Por favor vuelve más tarde.");
            return false;
        }
    }

    private void seleccionarEncuesta() {
        String seleccion = (String) vista.cbxNombreDeEncuesta.getSelectedItem();
        if (seleccion == null) return;

        if (encuestasRespondidas.contains(seleccion)) {
            JOptionPane.showMessageDialog(vista, "Ya has respondido esta encuesta. Selecciona otra.");
            limpiarVistaParaNuevaEncuesta();
            // Cambiado: cerrar programa directamente en vez de regresar al login
            vista.dispose();
            System.exit(0);
        } else {
            cargarPreguntasDeEncuesta();
        }
    }

    private void cargarPreguntasDeEncuesta() {
        encuestaSeleccionada = (String) vista.cbxNombreDeEncuesta.getSelectedItem();
        if (encuestaSeleccionada == null) return;

        MongoCollection<Document> coleccion = conexion.getCollection("Encuestas");
        Document encuestaDoc = coleccion.find(new Document("nombreEncuesta", encuestaSeleccionada)).first();

        if (encuestaDoc == null) return;

        listaPreguntas = (List<Document>) encuestaDoc.get("preguntas");
        preguntaActual = 0;
        respuestasMap.clear();

        mostrarPreguntaActual();
    }

    private void mostrarPreguntaActual() {
        if (preguntaActual >= listaPreguntas.size()) {
            JOptionPane.showMessageDialog(vista, "No hay más preguntas. Presione Enviar para finalizar.");
            vista.btnSiguiente.setVisible(false);
            vista.btnEnviar.setEnabled(true);
            limpiarSeleccion();
            return;
        }

        Document pregunta = listaPreguntas.get(preguntaActual);
        String textoPregunta = pregunta.getString("pregunta");
        List<String> opciones = (List<String>) pregunta.get("opciones");

        vista.labelPregunta.setText("Pregunta " + (preguntaActual + 1) + ": " + textoPregunta);

        vista.rbtPregunta1.setText(opciones.size() > 0 ? opciones.get(0) : "");
        vista.rbtPregunta2.setText(opciones.size() > 1 ? opciones.get(1) : "");
        vista.rbtPregunta3.setText(opciones.size() > 2 ? opciones.get(2) : "");
        vista.rbtPregunta4.setText(opciones.size() > 3 ? opciones.get(3) : "");

        vista.rbtPregunta1.setVisible(opciones.size() > 0);
        vista.rbtPregunta2.setVisible(opciones.size() > 1);
        vista.rbtPregunta3.setVisible(opciones.size() > 2);
        vista.rbtPregunta4.setVisible(opciones.size() > 3);

        ocultarLabelsError();

        if (preguntaActual == listaPreguntas.size() - 1) {
            vista.btnSiguiente.setVisible(false);
            vista.btnEnviar.setEnabled(true);
        } else {
            vista.btnSiguiente.setVisible(true);
            vista.btnEnviar.setEnabled(false);
        }

        limpiarSeleccion();
    }

    private void limpiarSeleccion() {
        grupoOpciones.clearSelection();
    }

    private boolean validarRespuestaSeleccionada() {
        if (!vista.rbtPregunta1.isSelected() && !vista.rbtPregunta2.isSelected()
                && !vista.rbtPregunta3.isSelected() && !vista.rbtPregunta4.isSelected()) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar una opción para continuar.");
            return false;
        }
        return true;
    }

    private String obtenerRespuestaSeleccionada() {
        if (vista.rbtPregunta1.isSelected()) return vista.rbtPregunta1.getText();
        if (vista.rbtPregunta2.isSelected()) return vista.rbtPregunta2.getText();
        if (vista.rbtPregunta3.isSelected()) return vista.rbtPregunta3.getText();
        if (vista.rbtPregunta4.isSelected()) return vista.rbtPregunta4.getText();
        return null;
    }

    private void siguientePregunta() {
        if (!validarRespuestaSeleccionada()) return;

        String respuesta = obtenerRespuestaSeleccionada();
        respuestasMap.put(preguntaActual, respuesta);

        preguntaActual++;
        mostrarPreguntaActual();
    }

    private void enviarRespuestas() {
        if (!validarRespuestaSeleccionada()) return;

        String respuesta = obtenerRespuestaSeleccionada();
        respuestasMap.put(preguntaActual, respuesta);

        List<String> listaRespuestasFinal = new ArrayList<>();
        for (int i = 0; i < listaPreguntas.size(); i++) {
            Document pregunta = listaPreguntas.get(i);
            String textoPregunta = pregunta.getString("pregunta");
            String resp = respuestasMap.getOrDefault(i, "Sin respuesta");
            listaRespuestasFinal.add(textoPregunta + ": " + resp);
        }

        MongoCollection<Document> coleccion = conexion.getCollection("Respuestas");
        Document respuestaDoc = new Document("cedulaEncuestado", encuestado.getCedula())
                .append("nombreEncuesta", encuestaSeleccionada)
                .append("respuestas", listaRespuestasFinal);

        coleccion.insertOne(respuestaDoc);
        encuestasRespondidas.add(encuestaSeleccionada);

        int opcion = JOptionPane.showConfirmDialog(vista,
                "Gracias por responder la encuesta.\n¿Quieres responder otra encuesta?",
                "Encuesta completada",
                JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            limpiarVistaParaNuevaEncuesta();
            if (!cargarEncuestasDisponibles()) {
                vista.dispose();
                System.exit(0);
            }
        } else {
            vista.dispose();
            System.exit(0);
        }
    }

    private void limpiarVistaParaNuevaEncuesta() {
        vista.labelPregunta.setText("");
        limpiarSeleccion();
        respuestasMap.clear();
        listaPreguntas = new ArrayList<>();
        encuestaSeleccionada = null;
        preguntaActual = 0;

        vista.btnEnviar.setEnabled(false);
        vista.btnSiguiente.setEnabled(true);
        vista.btnSiguiente.setVisible(true);
    }

    private void cancelar() {
        int opcion = JOptionPane.showConfirmDialog(vista,
                "¿Quieres salir y cerrar el programa?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            vista.dispose();
            System.exit(0);
        }
    }

    public void iniciar() {
        vista.setVisible(true);
    }
}
