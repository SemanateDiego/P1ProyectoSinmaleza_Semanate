package Controlador;

import Modelo.Administrador;
import Modelo.Encuestado;
import Modelo.DAO.UsuarioDAO;  // Importa el DAO que manejará el guardado
import Modelo.Validaciones.*;
import Vista.Registro;
import Vista.InicioSesion;

import javax.swing.*;

public class ControladorRegistro {
    private Registro vista;
    private final String PASSWORD_ADMIN = "admin123"; // Cambiar por la real
    private UsuarioDAO usuarioDAO = new UsuarioDAO(); // Instancia del DAO para guardar

    // Instancias de validadores
    private ValidadorNoVacio validadorNoVacio = new ValidadorNoVacio();
    private ValidadorCedula validadorCedula = new ValidadorCedula();
    private ValidadorCorreo validadorCorreo = new ValidadorCorreo();
    private ValidadorTelefono validadorTelefono = new ValidadorTelefono();
    private ValidadorEdad validadorEdad = new ValidadorEdad(18);

    public ControladorRegistro(Registro vista) {
        this.vista = vista;

        ocultarLabelsError();

        this.vista.btnGuardar.addActionListener(e -> registrarUsuario());
        this.vista.btnVolver.addActionListener(e -> volverAlLogin());

        this.vista.btnAdmin.addActionListener(e -> {
            if (vista.btnAdmin.isSelected()) {
                String pass = JOptionPane.showInputDialog(vista, "Ingrese contraseña de administrador:");
                if (pass == null || !pass.equals(PASSWORD_ADMIN)) {
                    JOptionPane.showMessageDialog(vista, "Contraseña incorrecta. No se seleccionará Administrador.", "Error", JOptionPane.ERROR_MESSAGE);
                    vista.btnAdmin.setSelected(false);
                }
            }
        });
    }
        public ControladorRegistro(Registro vista, UsuarioDAO usuarioDAO) {
        this.vista = vista;
        this.usuarioDAO = usuarioDAO;
        ocultarLabelsError();

        this.vista.btnGuardar.addActionListener(e -> registrarUsuario());
        this.vista.btnVolver.addActionListener(e -> volverAlLogin());

        this.vista.btnAdmin.addActionListener(e -> {
            if (vista.btnAdmin.isSelected()) {
                String pass = JOptionPane.showInputDialog(vista, "Ingrese contraseña de administrador:");
                if (pass == null || !pass.equals(PASSWORD_ADMIN)) {
                    JOptionPane.showMessageDialog(vista, "Contraseña incorrecta. No se seleccionará Administrador.", "Error", JOptionPane.ERROR_MESSAGE);
                    vista.btnAdmin.setSelected(false);
                }
            }
        });
        // Resto igual...
    }

    public void iniciar() {
        vista.setTitle("Registro de Usuario");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    public void ocultarLabelsError() {
        vista.labelErrrorNombre.setVisible(false);
        vista.labelErrorApellido.setVisible(false);
        vista.labelErrorCedula.setVisible(false);
        vista.LabelErrorCorreo.setVisible(false); // Correo
        vista.labelErrorGenero.setVisible(false);
        vista.LabelErrorTelefono.setVisible(false);
        vista.labelErrorUsuario.setVisible(false);
        vista.labelErrorContrasenia.setVisible(false);
        vista.labelErrorEdad.setVisible(false);
    }

    public boolean cedulaExiste(String cedula) {
        return usuarioDAO.cedulaExiste(cedula);
    }

    public void registrarUsuario() {
        ocultarLabelsError();

        String nombre = vista.txtNombre.getText().trim();
        String apellido = vista.TxtApellido.getText().trim();
        String cedula = vista.txtCedula.getText().trim();
        String correo = vista.TxtCorreo.getText().trim();
        String telefono = vista.txtTelefono.getText().trim();
        String usuario = vista.txtUsuario.getText().trim();
        String contrasenia = vista.txtContrasenia.getText().trim();
        int edad = (int) vista.spinnerEdad.getValue();
        String genero = vista.rbtnMasculino.isSelected() ? "M" : vista.rbtnFemenino.isSelected() ? "F" : "";

        boolean valid = true;

        if (!validadorNoVacio.validar(nombre)) {
            vista.labelErrrorNombre.setText(validadorNoVacio.getMensajeError());
            vista.labelErrrorNombre.setVisible(true);
            valid = false;
        }

        if (!validadorNoVacio.validar(apellido)) {
            vista.labelErrorApellido.setText(validadorNoVacio.getMensajeError());
            vista.labelErrorApellido.setVisible(true);
            valid = false;
        }

        if (!validadorCedula.validar(cedula)) {
            vista.labelErrorCedula.setText(validadorCedula.mensajeError());
            vista.labelErrorCedula.setVisible(true);
            valid = false;
        } else if (cedulaExiste(cedula)) {
            vista.labelErrorCedula.setText("La cédula ya está registrada");
            vista.labelErrorCedula.setVisible(true);
            valid = false;
        }

        if (!validadorCorreo.validar(correo)) {
            vista.LabelErrorCorreo.setText(validadorCorreo.mensajeError());
            vista.LabelErrorCorreo.setVisible(true);
            valid = false;
        }

        if (genero.isEmpty()) {
            vista.labelErrorGenero.setText("Seleccione género");
            vista.labelErrorGenero.setVisible(true);
            valid = false;
        }

        if (!validadorTelefono.validar(telefono)) {
            vista.LabelErrorTelefono.setText(validadorTelefono.mensajeError());
            vista.LabelErrorTelefono.setVisible(true);
            valid = false;
        }

        if (!validadorNoVacio.validar(usuario)) {
            vista.labelErrorUsuario.setText(validadorNoVacio.getMensajeError());
            vista.labelErrorUsuario.setVisible(true);
            valid = false;
        }

        if (!validadorNoVacio.validar(contrasenia)) {
            vista.labelErrorContrasenia.setText(validadorNoVacio.getMensajeError());
            vista.labelErrorContrasenia.setVisible(true);
            valid = false;
        }

        if (!validadorEdad.validar(edad)) {
            vista.labelErrorEdad.setText(validadorEdad.getMensajeError());
            vista.labelErrorEdad.setVisible(true);
            valid = false;
        }

        if (!valid) return;

        if (vista.btnAdmin.isSelected()) {
            Administrador admin = new Administrador("Administrador", nombre, apellido, cedula, correo, telefono, usuario,contrasenia);
            usuarioDAO.guardarAdministrador(admin);
            JOptionPane.showMessageDialog(vista, "Administrador registrado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            Encuestado encuestado = new Encuestado(edad, genero, false, nombre, apellido, cedula, correo, telefono, usuario, contrasenia);
            usuarioDAO.guardarEncuestado(encuestado);
            JOptionPane.showMessageDialog(vista, "Encuestado registrado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        }

        vista.dispose();
        abrirLogin();
    }

    public void abrirLogin() {
        InicioSesion vistaLogin = new InicioSesion();
        ControladorLogin controladorLogin = new ControladorLogin(vistaLogin);
        controladorLogin.iniciar();
    }

    private void volverAlLogin() {
        vista.dispose();
        abrirLogin();
    }
}
