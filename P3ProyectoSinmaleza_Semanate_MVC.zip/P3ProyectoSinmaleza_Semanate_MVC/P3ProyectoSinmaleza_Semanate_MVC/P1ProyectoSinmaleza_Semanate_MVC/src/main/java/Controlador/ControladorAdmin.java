package Controlador;

import Modelo.Administrador;
import Modelo.Encuestado;
import Modelo.DAO.ConexionMongoDB;
import Servicio.AdminService;
import Vista.Admin;
import Vista.InicioSesion;
import Vista.VistaEncuesta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.util.List;

public class ControladorAdmin {
    private final Admin vista;
    public final List<Administrador> listaAdministradores;
    public List<Encuestado> listaEncuestados;
    private final Administrador adminAutenticado;
    public final AdminService adminService;

    // Constructor original - crea AdminService con la base real
    public ControladorAdmin(Admin vista, Administrador adminAutenticado) {
        this(vista, adminAutenticado, new AdminService(new ConexionMongoDB()));
    }

    // Nuevo constructor para inyección de AdminService (test)
    public ControladorAdmin(Admin vista, Administrador adminAutenticado, AdminService adminService) {
        this.vista = vista;
        this.adminAutenticado = adminAutenticado;
        this.adminService = adminService;
        this.listaAdministradores = new ArrayList<>();
        this.listaEncuestados = new ArrayList<>();

        // Listeners
        this.vista.btnBuscar.addActionListener(e -> buscar());
        this.vista.btnActualizar.addActionListener(e -> actualizar());
        this.vista.btnEliminar.addActionListener(e -> eliminar());
        this.vista.btnAgregarEncuesta.addActionListener(e -> agregarEncuesta());
        this.vista.btnVolver.addActionListener(e -> volver());
        this.vista.btnDescargar.addActionListener(e -> descargarSeleccion());

        // Inicialización
        listaAdministradores.addAll(adminService.cargarAdministradores(adminAutenticado));
        listaEncuestados = adminService.cargarEncuestados();
        mostrarTabla();
        bloquearCampos(true);
    }



    public void descargarSeleccion() {
        if (vista.rbtnDescargarUsuarios.isSelected()) {
            boolean ok = adminService.exportarUsuariosCSV(listaAdministradores, listaEncuestados);
            JOptionPane.showMessageDialog(vista, ok ? "Usuarios exportados." : "Error al exportar usuarios.");
        } else {
            JOptionPane.showMessageDialog(vista, "Seleccione una opción para descargar.");
        }
    }

    private void mostrarTabla() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.setColumnIdentifiers(new String[]{"Nombre", "Apellido", "Cédula", "Correo", "Teléfono", "Usuario"});
        for (Encuestado e : listaEncuestados) {
            modelo.addRow(new String[]{
                    e.getNombre(), e.getApellido(), e.getCedula(),
                    e.getCorreo(), e.getTelefono(), e.getUsuario()
            });
        }
        vista.tableDatos.setModel(modelo);
    }

    public void buscar() {
        String cedula = JOptionPane.showInputDialog(vista, "Ingrese la cédula:");
        if (cedula == null || cedula.trim().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe ingresar una cédula válida.");
            return;
        }
        Encuestado encontrado = listaEncuestados.stream()
                .filter(e -> e.getCedula().equalsIgnoreCase(cedula.trim()))
                .findFirst().orElse(null);

        if (encontrado != null) {
            cargarDatosEncuestado(encontrado);
            bloquearCampos(false);
            vista.txtCedula.setEditable(false);
        } else {
            JOptionPane.showMessageDialog(vista, "Encuestado no encontrado.");
            limpiarCampos();
            bloquearCampos(true);
        }
    }

    private void cargarDatosEncuestado(Encuestado e) {
        vista.txtNombre.setText(e.getNombre());
        vista.txtApellido.setText(e.getApellido());
        vista.txtCedula.setText(e.getCedula());
        vista.txtCorreo.setText(e.getCorreo());
        vista.txtTelefono.setText(e.getTelefono());
        vista.txtUsuario.setText(e.getUsuario());
        vista.txtContrasenia.setText(e.getContrasenia());
    }

    private void bloquearCampos(boolean bloquear) {
        vista.txtNombre.setEditable(!bloquear);
        vista.txtApellido.setEditable(!bloquear);
        vista.txtCedula.setEditable(!bloquear);
        vista.txtCorreo.setEditable(!bloquear);
        vista.txtTelefono.setEditable(!bloquear);
        vista.txtUsuario.setEditable(!bloquear);
        vista.txtContrasenia.setEditable(!bloquear);
    }

    public void actualizar() {
        String cedula = vista.txtCedula.getText().trim();
        if (cedula.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe buscar un encuestado primero.");
            return;
        }
        for (Encuestado e : listaEncuestados) {
            if (e.getCedula().equalsIgnoreCase(cedula)) {
                e.setNombre(vista.txtNombre.getText().trim());
                e.setApellido(vista.txtApellido.getText().trim());
                e.setCorreo(vista.txtCorreo.getText().trim());
                e.setTelefono(vista.txtTelefono.getText().trim());
                e.setUsuario(vista.txtUsuario.getText().trim());
                e.setContrasenia(vista.txtContrasenia.getText().trim());

                adminService.actualizarEncuestadoEnBD(e);

                JOptionPane.showMessageDialog(vista, "Encuestado actualizado.");
                listaEncuestados = adminService.cargarEncuestados();
                mostrarTabla();
                bloquearCampos(true);
                limpiarCampos();
                return;
            }
        }
        JOptionPane.showMessageDialog(vista, "No se encontró el encuestado para actualizar.");
    }

    public void eliminar() {
        String cedula = vista.txtCedula.getText().trim();
        if (cedula.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe buscar un encuestado primero.");
            return;
        }
        boolean eliminado = adminService.eliminarEncuestadoPorCedula(cedula);
        if (eliminado) {
            JOptionPane.showMessageDialog(vista, "Encuestado eliminado.");
            listaEncuestados = adminService.cargarEncuestados();
            mostrarTabla();
            limpiarCampos();
            bloquearCampos(true);
        } else {
            JOptionPane.showMessageDialog(vista, "No se encontró el encuestado para eliminar.");
        }
    }

    private void agregarEncuesta() {
        VistaEncuesta vistaEncuesta = new VistaEncuesta();
        new ControladorVistaEncuesta(vistaEncuesta, true, new ConexionMongoDB().getDatabase(), null).iniciar();
    }

    private void volver() {
        vista.dispose();
        new ControladorLogin(new InicioSesion()).iniciar();
    }

    private void limpiarCampos() {
        vista.txtNombre.setText("");
        vista.txtApellido.setText("");
        vista.txtCedula.setText("");
        vista.txtCorreo.setText("");
        vista.txtTelefono.setText("");
        vista.txtUsuario.setText("");
        vista.txtContrasenia.setText("");
    }

    public void iniciar() {
        vista.setVisible(true);
    }
}
