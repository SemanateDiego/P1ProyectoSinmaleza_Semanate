package main;
//Librerias
import Controlador.ControladorLogin;
import Vista.InicioSesion;
public class P1ProyectoSinmaleza_Semanate {
    public static void main(String[] args) {
        InicioSesion login = new InicioSesion();
            ControladorLogin controlador = new ControladorLogin(login);
            controlador.iniciar();
    }
}
