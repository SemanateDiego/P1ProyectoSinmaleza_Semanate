package Servicio;

import Modelo.Administrador;
import Modelo.Encuestado;
import Modelo.DAO.ConexionMongoDB;
import org.bson.Document;
import com.mongodb.client.MongoCollection;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AdminService {
    private final ConexionMongoDB conexion;

    public AdminService(ConexionMongoDB conexion) {
        this.conexion = conexion;
    }

    public List<Administrador> cargarAdministradores(Administrador adminAutenticado) {
        List<Administrador> lista = new ArrayList<>();
        if (adminAutenticado != null) {
            lista.add(adminAutenticado);
        }
        return lista;
    }

    public List<Encuestado> cargarEncuestados() {
        List<Encuestado> lista = new ArrayList<>();
        MongoCollection<Document> coleccion = conexion.getCollection("Encuestados");
        List<Document> documentos = coleccion.find().into(new ArrayList<>());

        for (Document doc : documentos) {
            lista.add(new Encuestado(
                doc.getInteger("edad", 0),
                doc.getString("genero"),
                doc.getBoolean("encuestaCompletada", false),
                doc.getString("nombre"),
                doc.getString("apellido"),
                doc.getString("cedula"),
                doc.getString("correo"),
                doc.getString("telefono"),
                doc.getString("usuario"),
                doc.getString("contrasenia")
            ));
        }
        return lista;
    }

    public void actualizarEncuestadoEnBD(Encuestado e) {
        MongoCollection<Document> coleccion = conexion.getCollection("Encuestados");
        Document filtro = new Document("cedula", e.getCedula());
        Document nuevosDatos = new Document("$set", new Document()
            .append("nombre", e.getNombre())
            .append("apellido", e.getApellido())
            .append("correo", e.getCorreo())
            .append("telefono", e.getTelefono())
            .append("usuario", e.getUsuario())
            .append("contrasenia", e.getContrasenia())
        );
        coleccion.updateOne(filtro, nuevosDatos);
    }

    public boolean eliminarEncuestadoPorCedula(String cedula) {
        MongoCollection<Document> coleccion = conexion.getCollection("Encuestados");
        Document filtro = new Document("cedula", cedula);
        long eliminado = coleccion.deleteOne(filtro).getDeletedCount();
        return eliminado > 0;
    }

    public String safeGet(Document doc, String key) {
        Object val = doc.get(key);
        return val == null ? "" : val.toString();
    }

    public boolean exportarUsuariosCSV(List<Administrador> admins, List<Encuestado> encuestados) {
        MongoCollection<Document> adminsCollection = conexion.getCollection("Administradores");
        List<Document> docsAdmins = adminsCollection.find().into(new ArrayList<>());

        try (FileWriter writer = new FileWriter("usuarios_registrados.csv")) {
            writer.append("Tipo,Nombre,Apellido,Cedula,Correo,Telefono,Usuario\n");
            for (Document doc : docsAdmins) {
                writer.append("Administrador,")
                        .append(safeGet(doc, "nombre")).append(",")
                        .append(safeGet(doc, "apellido")).append(",")
                        .append(safeGet(doc, "cedula")).append(",")
                        .append(safeGet(doc, "correo")).append(",")
                        .append(safeGet(doc, "telefono")).append(",")
                        .append(safeGet(doc, "usuario")).append("\n");
            }
            for (Encuestado e : encuestados) {
                writer.append("Encuestado,")
                        .append(e.getNombre()).append(",")
                        .append(e.getApellido()).append(",")
                        .append(e.getCedula()).append(",")
                        .append(e.getCorreo()).append(",")
                        .append(e.getTelefono()).append(",")
                        .append(e.getUsuario()).append("\n");
            }
            return true;
        } catch (IOException ex) {
            return false;
        }
    }
}

