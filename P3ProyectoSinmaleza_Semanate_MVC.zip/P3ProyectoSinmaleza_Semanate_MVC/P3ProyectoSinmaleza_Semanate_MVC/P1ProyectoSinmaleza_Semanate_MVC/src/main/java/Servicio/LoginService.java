package Servicio;

import Modelo.Administrador;
import Modelo.DAO.ValidarUsuario;
import Modelo.Encuestado;
import org.bson.Document;

public class LoginService {
    private final ValidarUsuario usuarioModelo;

    public LoginService(ValidarUsuario usuarioModelo) {
        this.usuarioModelo = usuarioModelo;
    }

    public Document validarCredenciales(String usuario, String contrasena) {
        if (usuario == null || usuario.isEmpty() || contrasena == null || contrasena.isEmpty()) {
            return null;
        }
        return usuarioModelo.validarUsuario(usuario, contrasena);
    }

    public String obtenerStringSeguro(Document doc, String clave) {
        if (doc == null) return "";
        String valor = doc.getString(clave);
        return (valor != null) ? valor : "";
    }

    public Administrador crearAdministrador(Document datosUsuario) {
        return new Administrador(
            obtenerStringSeguro(datosUsuario, "rol"),
            obtenerStringSeguro(datosUsuario, "nombre"),
            obtenerStringSeguro(datosUsuario, "apellido"),
            obtenerStringSeguro(datosUsuario, "cedula"),
            obtenerStringSeguro(datosUsuario, "correo"),
            obtenerStringSeguro(datosUsuario, "telefono"),
            obtenerStringSeguro(datosUsuario, "usuario"),
            obtenerStringSeguro(datosUsuario, "contrasenia")
        );
    }

    public Encuestado crearEncuestado(Document datosUsuario) {
        return new Encuestado(
            datosUsuario.getInteger("edad", 0),
            obtenerStringSeguro(datosUsuario, "genero"),
            datosUsuario.getBoolean("encuestaCompletada", false),
            obtenerStringSeguro(datosUsuario, "nombre"),
            obtenerStringSeguro(datosUsuario, "apellido"),
            obtenerStringSeguro(datosUsuario, "cedula"),
            obtenerStringSeguro(datosUsuario, "correo"),
            obtenerStringSeguro(datosUsuario, "telefono"),
            obtenerStringSeguro(datosUsuario, "usuario"),
            obtenerStringSeguro(datosUsuario, "contrasenia")
        );
    }
}

