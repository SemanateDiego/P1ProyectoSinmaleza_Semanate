package PatronesDiseño;

import java.util.ArrayList;
import java.util.List;
import org.bson.Document;

public class Memento {
    private final List<Document> estado;

    public Memento(List<Document> estado) {
        this.estado = new ArrayList<>(estado);
    }

    public List<Document> getEstado() {
        return new ArrayList<>(estado);
    }
}
