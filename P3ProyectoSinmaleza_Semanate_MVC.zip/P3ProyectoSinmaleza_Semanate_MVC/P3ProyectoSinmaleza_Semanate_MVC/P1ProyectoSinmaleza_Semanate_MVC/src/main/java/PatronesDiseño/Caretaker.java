package PatronesDiseño;

import java.util.Stack;

public class Caretaker {
    private final Stack<Memento> undoStack = new Stack<>();
    private final Stack<Memento> redoStack = new Stack<>();

    public void guardar(Memento m) {
        undoStack.push(m);
        redoStack.clear();
    }

    public Memento deshacer() {
        if (!undoStack.isEmpty()) {
            Memento m = undoStack.pop();
            redoStack.push(m);
            return m;
        }
        return null;
    }

    public Memento rehacer() {
        if (!redoStack.isEmpty()) {
            Memento m = redoStack.pop();
            undoStack.push(m);
            return m;
        }
        return null;
    }
}
