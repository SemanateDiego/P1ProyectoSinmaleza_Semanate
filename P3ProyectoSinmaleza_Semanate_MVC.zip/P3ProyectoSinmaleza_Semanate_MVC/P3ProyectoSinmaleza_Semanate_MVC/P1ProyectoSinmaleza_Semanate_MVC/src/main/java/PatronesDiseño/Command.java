package PatronesDiseño;

public interface Command {
    void ejecutar();
    void deshacer();
}

