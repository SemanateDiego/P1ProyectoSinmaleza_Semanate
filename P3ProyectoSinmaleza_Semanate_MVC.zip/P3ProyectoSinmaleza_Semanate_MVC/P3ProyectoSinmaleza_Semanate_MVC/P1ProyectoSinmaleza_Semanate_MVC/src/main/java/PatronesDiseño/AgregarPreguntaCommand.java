package PatronesDiseño;

import Controlador.ControladorVistaEncuesta;
import org.bson.Document;

public class AgregarPreguntaCommand implements Command {
    private ControladorVistaEncuesta controlador;
    private Document pregunta;

    public AgregarPreguntaCommand(ControladorVistaEncuesta controlador, Document pregunta) {
        this.controlador = controlador;
        this.pregunta = pregunta;
    }

    @Override
    public void ejecutar() {
        controlador.agregarPreguntaDesdeCommand(pregunta);
    }

    @Override
    public void deshacer() {
        controlador.eliminarUltimaPreguntaDesdeCommand();
    }
}

