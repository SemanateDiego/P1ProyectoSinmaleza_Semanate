package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Sistema {
    private List<Administrador> administradores;
    private List<Encuestado> encuestados;
    private List<Encuesta> encuestas;

    public Sistema() {
        this.administradores = new ArrayList<>();
        this.encuestados = new ArrayList<>();
        this.encuestas = new ArrayList<>();
    }

    public void agregarAdministrador(Administrador admin) {
        administradores.add(admin);
    }

    public void agregarEncuestado(Encuestado encuestado) {
        encuestados.add(encuestado);
    }

    public void agregarEncuesta(Encuesta encuesta) {
        encuestas.add(encuesta);
    }

    public List<Administrador> getAdministradores() {
        return administradores;
    }

    public List<Encuestado> getEncuestados() {
        return encuestados;
    }

    public List<Encuesta> getEncuestas() {
        return encuestas;
    }
}
