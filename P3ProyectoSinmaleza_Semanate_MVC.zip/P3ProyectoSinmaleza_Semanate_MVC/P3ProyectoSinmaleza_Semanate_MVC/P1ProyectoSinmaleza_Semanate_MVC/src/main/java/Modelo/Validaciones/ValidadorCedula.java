package Modelo.Validaciones;

public class ValidadorCedula implements IValidacion<String> {

    @Override
    public boolean validar(String cedula) {
        if (cedula == null || cedula.length() != 10) return false;

        try {
            int total = 0;
            int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
            int verificador = Integer.parseInt(cedula.substring(9));

            for (int i = 0; i < 9; i++) {
                int valor = Integer.parseInt(String.valueOf(cedula.charAt(i))) * coeficientes[i];
                if (valor > 9) valor -= 9;
                total += valor;
            }

            int decena = ((total + 9) / 10) * 10;
            int digitoCalculado = decena - total;
            if (digitoCalculado == 10) digitoCalculado = 0;

            return digitoCalculado == verificador;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public String mensajeError() {
        return "La cédula ingresada no es válida.";
    }
}
