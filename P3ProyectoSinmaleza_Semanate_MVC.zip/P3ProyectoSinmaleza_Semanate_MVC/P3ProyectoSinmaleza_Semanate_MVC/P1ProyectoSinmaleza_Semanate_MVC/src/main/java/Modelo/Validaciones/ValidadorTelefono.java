package Modelo.Validaciones;

public class ValidadorTelefono implements IValidacion<String> {

    @Override
    public boolean validar(String telefono) {
        return telefono != null && telefono.matches("\\d{9,10}");
    }

    @Override
    public String mensajeError() {
        return "El número de teléfono debe tener 9 o 10 dígitos.";
    }
}

