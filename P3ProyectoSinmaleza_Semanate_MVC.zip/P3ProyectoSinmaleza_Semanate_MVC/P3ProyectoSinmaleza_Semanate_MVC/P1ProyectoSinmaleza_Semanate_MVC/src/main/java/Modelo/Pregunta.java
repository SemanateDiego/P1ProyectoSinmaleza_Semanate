package Modelo;

public abstract class Pregunta {
    protected String textoPregunta;

    public Pregunta(String textoPregunta) {
        this.textoPregunta = textoPregunta;
    }

    public String getTextoPregunta() {
        return textoPregunta;
    }

    public abstract String getTipoPregunta();
}
