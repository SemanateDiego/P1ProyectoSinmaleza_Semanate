package Modelo.Interfaces;

public interface IDAO<T> {
    void guardar(T entidad);
    boolean existePorCedula(String cedula);
}
