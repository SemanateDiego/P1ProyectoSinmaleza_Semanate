package Modelo.Validaciones;

public class ValidadorNoVacio {
    private String mensajeError;

    public boolean validar(String valor) {
        if (valor == null || valor.trim().isEmpty()) {
            mensajeError = "El campo no puede estar vacío";
            return false;
        }
        mensajeError = "";
        return true;
    }

    public String getMensajeError() {
        return mensajeError;
    }
}

