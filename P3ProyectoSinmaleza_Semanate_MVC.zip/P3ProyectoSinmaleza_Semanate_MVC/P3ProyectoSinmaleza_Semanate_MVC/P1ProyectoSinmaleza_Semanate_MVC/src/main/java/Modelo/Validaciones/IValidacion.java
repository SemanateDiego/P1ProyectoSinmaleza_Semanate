package Modelo.Validaciones;

public interface IValidacion<T> {
    boolean validar(T valor);
    String mensajeError();
}
