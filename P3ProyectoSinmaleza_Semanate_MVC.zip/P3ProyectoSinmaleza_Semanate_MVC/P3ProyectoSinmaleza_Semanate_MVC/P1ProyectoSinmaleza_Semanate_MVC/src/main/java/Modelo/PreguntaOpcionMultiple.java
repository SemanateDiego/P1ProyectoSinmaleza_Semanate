package Modelo;

import java.util.List;

public class PreguntaOpcionMultiple extends Pregunta {
    private List<String> opciones;

    public PreguntaOpcionMultiple(String textoPregunta, List<String> opciones) {
        super(textoPregunta);
        this.opciones = opciones;
    }

    public List<String> getOpciones() {
        return opciones;
    }

    @Override
    public String getTipoPregunta() {
        return "OpcionMultiple";
    }
}
