package Modelo.Interfaces;

import org.bson.Document;

public interface ILoginValidacion {
    Document validarUsuario(String usuario, String contrasenia);
}
