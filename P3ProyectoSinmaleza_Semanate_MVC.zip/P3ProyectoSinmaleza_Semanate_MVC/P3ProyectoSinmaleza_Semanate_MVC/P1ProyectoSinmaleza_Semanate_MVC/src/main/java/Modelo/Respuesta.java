package Modelo;

public class Respuesta {
    private String cedulaEncuestado;
    private String nombreEncuesta;
    private String respuesta;

    public Respuesta(String cedulaEncuestado, String nombreEncuesta, String respuesta) {
        this.cedulaEncuestado = cedulaEncuestado;
        this.nombreEncuesta = nombreEncuesta;
        this.respuesta = respuesta;
    }

    public String getCedulaEncuestado() { return cedulaEncuestado; }
    public String getNombreEncuesta() { return nombreEncuesta; }
    public String getRespuesta() { return respuesta; }

    public void setCedulaEncuestado(String cedulaEncuestado) { this.cedulaEncuestado = cedulaEncuestado; }
    public void setNombreEncuesta(String nombreEncuesta) { this.nombreEncuesta = nombreEncuesta; }
    public void setRespuesta(String respuesta) { this.respuesta = respuesta; }
}
