package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Encuesta {
    private String nombre;
    private String descripcion;
    private List<Pregunta> preguntas;

    public Encuesta(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.preguntas = new ArrayList<>();
    }

    public void agregarPregunta(Pregunta pregunta) {
        preguntas.add(pregunta);
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Pregunta> getPreguntas() {
        return preguntas;
    }
}
