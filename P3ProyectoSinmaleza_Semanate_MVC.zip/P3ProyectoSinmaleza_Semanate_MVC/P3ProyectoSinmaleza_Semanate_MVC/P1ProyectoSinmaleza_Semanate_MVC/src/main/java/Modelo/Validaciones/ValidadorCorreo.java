package Modelo.Validaciones;

public class ValidadorCorreo implements IValidacion<String> {

    @Override
    public boolean validar(String correo) {
        return correo != null && correo.contains("@") && correo.contains(".");
    }

    @Override
    public String mensajeError() {
        return "El correo electrónico es inválido.";
    }
}
