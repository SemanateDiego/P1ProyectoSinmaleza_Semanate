package Modelo.Interfaces;

import java.util.List;

/**
 * Interfaz genérica CRUD para operaciones básicas de persistencia.
 * @param <T> Tipo de entidad que maneja el CRUD
 */
public interface CRUDInterface<T> {
    /**
     * Inserta un nuevo registro.
     * @param obj objeto a insertar
     * @return true si la operación fue exitosa, false en caso contrario
     */
    boolean crear(T obj);

    /**
     * Obtiene un registro por su identificador o criterio único.
     * @param id identificador del objeto
     * @return objeto encontrado o null si no existe
     */
    T leer(Object id);

    /**
     * Actualiza un registro existente.
     * @param obj objeto con datos actualizados
     * @return true si la actualización fue exitosa, false en caso contrario
     */
    boolean actualizar(T obj);

    /**
     * Elimina un registro.
     * @param id identificador del objeto a eliminar
     * @return true si la eliminación fue exitosa, false en caso contrario
     */
    boolean eliminar(Object id);

    /**
     * Lista todos los registros.
     * @return lista de objetos
     */
    List<T> listar();
}
