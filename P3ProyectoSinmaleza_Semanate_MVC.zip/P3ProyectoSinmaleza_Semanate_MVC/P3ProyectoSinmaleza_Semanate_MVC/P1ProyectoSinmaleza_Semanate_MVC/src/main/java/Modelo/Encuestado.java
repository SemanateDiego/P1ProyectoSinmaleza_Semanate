package Modelo;

public class Encuestado extends Persona {
    private int edad;
    private String genero;
    private boolean encuestaCompletada;

    public Encuestado(int edad, String genero, boolean encuestaCompletada,
                      String nombre, String apellido, String cedula, String correo,
                      String telefono, String usuario, String contrasenia) {
        super(nombre, apellido, cedula, correo, telefono, usuario, contrasenia);
        this.edad = edad;
        this.genero = genero;
        this.encuestaCompletada = encuestaCompletada;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public boolean isEncuestaCompletada() {
        return encuestaCompletada;
    }

    public void setEncuestaCompletada(boolean encuestaCompletada) {
        this.encuestaCompletada = encuestaCompletada;
    }
}
