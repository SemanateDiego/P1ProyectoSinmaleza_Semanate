package Modelo.DAO;

import Modelo.Encuestado;
import Modelo.Interfaces.IDAO;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class EncuestadoDAO implements IDAO<Encuestado> {
    private final ConexionMongoDB conexion;

    public EncuestadoDAO() {
        this.conexion = new ConexionMongoDB();
    }

    @Override
    public void guardar(Encuestado encuestado) {
        MongoCollection<Document> collection = conexion.getCollection("Encuestados");
        Document doc = new Document("rol", "Encuestado")
                .append("nombre", encuestado.getNombre())
                .append("apellido", encuestado.getApellido())
                .append("cedula", encuestado.getCedula())
                .append("correo", encuestado.getCorreo())
                .append("telefono", encuestado.getTelefono())
                .append("usuario", encuestado.getUsuario())
                .append("contrasenia", encuestado.getContrasenia())
                .append("edad", encuestado.getEdad())
                .append("genero", encuestado.getGenero())
                .append("encuestaCompletada", encuestado.isEncuestaCompletada());
        collection.insertOne(doc);
    }

    @Override
    public boolean existePorCedula(String cedula) {
        MongoCollection<Document> collection = conexion.getCollection("Encuestados");
        return collection.find(new Document("cedula", cedula)).first() != null;
    }
}
