package Modelo.DAO;

import org.bson.Document;

public interface IUsuarioDAO {
    Document validarCredenciales(String usuario, String contrasenia);
}
