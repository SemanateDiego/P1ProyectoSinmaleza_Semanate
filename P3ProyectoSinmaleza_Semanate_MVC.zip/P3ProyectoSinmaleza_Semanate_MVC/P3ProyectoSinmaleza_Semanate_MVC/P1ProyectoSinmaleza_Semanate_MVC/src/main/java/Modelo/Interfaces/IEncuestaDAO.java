package Modelo.Interfaces;

import org.bson.Document;
import java.util.List;

public interface IEncuestaDAO {
    void guardarEncuesta(String nombre, List<Document> preguntas);
    List<Document> obtenerEncuestasPendientes(String cedulaEncuestado);
    List<Document> obtenerPreguntas(String nombreEncuesta);
}
