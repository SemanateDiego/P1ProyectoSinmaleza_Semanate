package Modelo.Interfaces;

import Modelo.Persona;

public interface IUsuarioDAO extends IDAO<Persona> {
    Persona validarUsuario(String usuario, String contrasenia);
    boolean existeCedula(String cedula);
}
