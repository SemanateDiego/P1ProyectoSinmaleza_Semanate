package Modelo.Validaciones;

public class ValidadorEdad {
    private int edadMinima;
    private String mensajeError;

    // Constructor con parámetro
    public ValidadorEdad(int edadMinima) {
        this.edadMinima = edadMinima;
        this.mensajeError = "";
    }

    public boolean validar(int edad) {
        if (edad < edadMinima) {
            mensajeError = "La edad mínima es " + edadMinima;
            return false;
        }
        return true;
    }

    public String getMensajeError() {
        return mensajeError;
    }
}
