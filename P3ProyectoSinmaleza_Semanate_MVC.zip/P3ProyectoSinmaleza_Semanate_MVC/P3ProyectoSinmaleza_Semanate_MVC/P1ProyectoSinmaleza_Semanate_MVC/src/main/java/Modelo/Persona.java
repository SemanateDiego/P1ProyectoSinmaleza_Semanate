package Modelo;

public abstract class Persona {
    protected String nombre;
    protected String apellido;
    protected String cedula;
    protected String correo;
    protected String telefono;
    protected String usuario;
    protected String contrasenia;

    public Persona(String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String contrasenia) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.correo = correo;
        this.telefono = telefono;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }

    // Getters y setters
    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getCedula() { return cedula; }
    public String getCorreo() { return correo; }
    public String getTelefono() { return telefono; }
    public String getUsuario() { return usuario; }
    public String getContrasenia() { return contrasenia; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public void setCedula(String cedula) { this.cedula = cedula; }
    public void setCorreo(String correo) { this.correo = correo; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public void setContrasenia(String contrasenia) { this.contrasenia = contrasenia; }
}
