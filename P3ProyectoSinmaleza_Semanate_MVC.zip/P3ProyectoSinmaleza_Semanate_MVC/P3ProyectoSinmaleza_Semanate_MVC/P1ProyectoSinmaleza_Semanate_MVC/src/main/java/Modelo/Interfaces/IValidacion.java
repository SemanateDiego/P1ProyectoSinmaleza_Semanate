package Modelo.Interfaces;

public interface IValidacion {
    boolean validar(String valor);
}
