package Modelo;

public class PreguntaTexto extends Pregunta {

    public PreguntaTexto(String textoPregunta) {
        super(textoPregunta);
    }

    @Override
    public String getTipoPregunta() {
        return "Texto";
    }
}
