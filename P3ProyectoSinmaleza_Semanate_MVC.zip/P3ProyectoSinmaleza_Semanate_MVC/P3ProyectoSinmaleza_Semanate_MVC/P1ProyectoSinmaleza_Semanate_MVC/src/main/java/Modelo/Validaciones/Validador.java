package Modelo.Validaciones;

import java.util.ArrayList;
import java.util.List;

public class Validador {

    private List<String> errores = new ArrayList<>();

    public <T> void agregarValidacion(T valor, IValidacion<T> regla) {
        if (!regla.validar(valor)) {
            errores.add(regla.mensajeError());
        }
    }

    public boolean esValido() {
        return errores.isEmpty();
    }

    public List<String> getErrores() {
        return errores;
    }

    public void limpiar() {
        errores.clear();
    }
}
