package Modelo.Interfaces;

public interface IRegistroUsuario {
    boolean cedulaYaExiste(String cedula);
    boolean telefonoValido(String telefono);
}
