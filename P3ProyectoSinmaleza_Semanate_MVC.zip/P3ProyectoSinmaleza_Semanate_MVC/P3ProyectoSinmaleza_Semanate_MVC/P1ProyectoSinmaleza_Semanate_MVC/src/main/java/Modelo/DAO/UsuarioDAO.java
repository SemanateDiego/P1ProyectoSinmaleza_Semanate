package Modelo.DAO;

import Modelo.Administrador;
import Modelo.Encuestado;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import Modelo.DAO.ConexionMongoDB;

import java.io.FileWriter;
import java.io.IOException;

public class UsuarioDAO {
    private ConexionMongoDB conexion = new ConexionMongoDB();

    public void guardarAdministrador(Administrador admin) {
        MongoCollection<Document> coleccion = conexion.getCollection("Administradores");

        Document doc = new Document()
            .append("rol", "Administrador")
            .append("nombre", admin.getNombre())
            .append("apellido", admin.getApellido())
            .append("cedula", admin.getCedula())
            .append("correo", admin.getCorreo())
            .append("telefono", admin.getTelefono())
            .append("usuario", admin.getUsuario())
            .append("contrasenia", admin.getContrasenia());

        coleccion.insertOne(doc);

        guardarAdministradorEnCSV(admin);
    }

    private void guardarAdministradorEnCSV(Administrador admin) {
        try (FileWriter fw = new FileWriter("administradores.csv", true)) {
            fw.append(admin.getNombre()).append(",")
              .append(admin.getApellido()).append(",")
              .append(admin.getCedula()).append(",")
              .append(admin.getCorreo()).append(",")
              .append(admin.getTelefono()).append(",")
              .append(admin.getUsuario()).append(",")
              .append(admin.getContrasenia()).append("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public boolean cedulaExiste(String cedula) {
    // Verificar en colección Administradores
    MongoCollection<Document> admins = conexion.getCollection("Administradores");
    if (admins.find(new Document("cedula", cedula)).first() != null) {
        return true;
    }
    // Verificar en colección Encuestados
    MongoCollection<Document> encuestados = conexion.getCollection("Encuestados");
    if (encuestados.find(new Document("cedula", cedula)).first() != null) {
        return true;
    }
    return false;
}


    public void guardarEncuestado(Encuestado encuestado) {
        MongoCollection<Document> coleccion = conexion.getCollection("Encuestados");

        Document doc = new Document()
            .append("rol", "Encuestado")
            .append("edad", encuestado.getEdad())
            .append("genero", encuestado.getGenero())
            .append("encuestaCompletada", encuestado.isEncuestaCompletada())
            .append("nombre", encuestado.getNombre())
            .append("apellido", encuestado.getApellido())
            .append("cedula", encuestado.getCedula())
            .append("correo", encuestado.getCorreo())
            .append("telefono", encuestado.getTelefono())
            .append("usuario", encuestado.getUsuario())
            .append("contrasenia", encuestado.getContrasenia());

        coleccion.insertOne(doc);

        guardarEncuestadoEnCSV(encuestado);
    }

    private void guardarEncuestadoEnCSV(Encuestado encuestado) {
        try (FileWriter fw = new FileWriter("encuestados.csv", true)) {
            fw.append(String.valueOf(encuestado.getEdad())).append(",")
              .append(encuestado.getGenero()).append(",")
              .append(String.valueOf(encuestado.isEncuestaCompletada())).append(",")
              .append(encuestado.getNombre()).append(",")
              .append(encuestado.getApellido()).append(",")
              .append(encuestado.getCedula()).append(",")
              .append(encuestado.getCorreo()).append(",")
              .append(encuestado.getTelefono()).append(",")
              .append(encuestado.getUsuario()).append(",")
              .append(encuestado.getContrasenia()).append("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
