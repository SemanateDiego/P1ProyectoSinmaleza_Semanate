package Modelo;

public class Administrador extends Persona {
    private String rol;

    public Administrador(String rol, String nombre, String apellido, String cedula, String correo, String telefono, String usuario, String contrasenia) {
        super(nombre, apellido, cedula, correo, telefono, usuario, contrasenia);
        this.rol = rol;
    }
   
    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
}
