package Modelo.DAO;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class ConexionMongoDB {
    private final MongoClient cliente;
    private final MongoDatabase database;

    public ConexionMongoDB() {
        cliente = MongoClients.create("mongodb://localhost:27017");
        database = cliente.getDatabase("P2ProyectoGrupal");
    }

    public MongoCollection<Document> getCollection(String nombre) {
        return database.getCollection(nombre);
    }
    public MongoDatabase getDatabase() {
        return database;
    }

    public void cerrarConexion() {
        cliente.close();
    }
}
