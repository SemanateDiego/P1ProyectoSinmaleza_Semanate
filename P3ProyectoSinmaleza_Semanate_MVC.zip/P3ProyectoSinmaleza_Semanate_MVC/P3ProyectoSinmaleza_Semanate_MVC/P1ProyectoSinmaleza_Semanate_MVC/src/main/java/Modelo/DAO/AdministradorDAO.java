package Modelo.DAO;

import Modelo.Administrador;
import Modelo.Interfaces.IDAO;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class AdministradorDAO implements IDAO<Administrador> {
    private final ConexionMongoDB conexion;

    // Constructor original para uso real
    public AdministradorDAO() {
        this.conexion = new ConexionMongoDB();
    }

    // Constructor para pruebas (inyección de dependencia)
    public AdministradorDAO(ConexionMongoDB conexion) {
        this.conexion = conexion;
    }

    @Override
    public void guardar(Administrador admin) {
        MongoCollection<Document> collection = conexion.getCollection("Administradores");
        Document doc = new Document("rol", admin.getRol())
                .append("nombre", admin.getNombre())
                .append("apellido", admin.getApellido())
                .append("cedula", admin.getCedula())
                .append("correo", admin.getCorreo())
                .append("telefono", admin.getTelefono())
                .append("usuario", admin.getUsuario())
                .append("contrasenia", admin.getContrasenia());
        collection.insertOne(doc);
    }

    @Override
    public boolean existePorCedula(String cedula) {
        MongoCollection<Document> collection = conexion.getCollection("Administradores");
        return collection.find(new Document("cedula", cedula)).first() != null;
    }
}

