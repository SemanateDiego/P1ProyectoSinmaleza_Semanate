package Modelo.DAO;

import Modelo.Interfaces.ILoginValidacion;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class ValidarUsuario implements ILoginValidacion {

    private ConexionMongoDB conexion;

    public ValidarUsuario() {
        conexion = new ConexionMongoDB();
    }

    @Override
    public Document validarUsuario(String usuario, String contrasenia) {
        MongoCollection<Document> adminCollection = conexion.getCollection("Administradores");
        MongoCollection<Document> encuestadoCollection = conexion.getCollection("Encuestados");

        Document filtro = new Document("usuario", usuario).append("contrasenia", contrasenia);
        Document admin = adminCollection.find(filtro).first();
        if (admin != null) return admin;

        Document encuestado = encuestadoCollection.find(filtro).first();
        return encuestado;
    }
}
