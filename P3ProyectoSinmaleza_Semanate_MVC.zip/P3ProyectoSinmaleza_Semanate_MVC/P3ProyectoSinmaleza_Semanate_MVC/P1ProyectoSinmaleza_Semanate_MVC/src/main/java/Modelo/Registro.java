package Modelo;

public class Registro {
    private String usuario;
    private String contrasenia;

    public Registro(String usuario, String contrasenia) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }

    public String getUsuario() { return usuario; }
    public String getContrasenia() { return contrasenia; }

    public void setUsuario(String usuario) { this.usuario = usuario; }
    public void setContrasenia(String contrasenia) { this.contrasenia = contrasenia; }
}
